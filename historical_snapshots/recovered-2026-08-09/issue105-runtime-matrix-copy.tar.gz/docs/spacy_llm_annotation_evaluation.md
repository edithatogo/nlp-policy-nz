# spaCy-llm Annotation Evaluation

Track 64 evaluates `spacy-llm` as an optional annotation layer for reviewable
LLM-assisted extraction inside the existing spaCy pipeline.

## Candidate paths

- `spacy-llm` for prompt-driven spaCy tasks when the package is installed.
- Track 62 local inference via vLLM for CI-friendly prompt execution.
- Deterministic custom prompt code for Windows, offline, and GitHub Actions
  fallback paths.

## Decision boundary

The repository keeps deterministic spaCy components as the canonical path.
`spacy-llm` stays optional and is only used where it improves reviewable
annotation workflows without replacing the accepted baseline.

## Evaluation focus

- candidate versus accepted label separation
- span preservation for annotation spans
- local inference compatibility when Track 62 is available
- comparison against DSPy-style or custom prompt code

## Evidence boundary

The repo-side evaluation is deterministic. It is sufficient for deciding
whether `spacy-llm` should remain optional, but it is not a substitute for a
live external benchmark if one is later introduced.

