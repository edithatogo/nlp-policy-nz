# Track 65: spaCy-transformers Pipeline Upgrade

Track 65 evaluates `spacy-transformers` as an optional upgrade path for spaCy
components that need contextual embeddings, while keeping the deterministic
spaCy baseline as the canonical fallback.

## What This Adds

- Optional transformer-backed components for legal NLP cases that benefit from
  richer shared context.
- Token/span alignment checks that keep the legal pipeline reviewable.
- Māori token compatibility checks so macron-bearing text stays intact.
- A deterministic fallback lane when the optional dependency is unavailable.

## What It Does Not Change

- It does not make `spacy-transformers` required.
- It does not replace the current spaCy tokenisation baseline.
- It does not remove the non-transformer path for CI or local development.

## Decision Boundary

The upgrade is only worth carrying forward where measured quality gains exceed
the added dependency and runtime cost. If the transformer-backed path does not
improve the target component materially, the repo should keep the baseline
spaCy path and defer the upgrade.
