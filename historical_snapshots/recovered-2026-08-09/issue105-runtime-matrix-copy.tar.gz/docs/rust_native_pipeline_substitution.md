# Rust-Native Pipeline Substitution Survey

Track 67 reviews whether additional Rust-native libraries should replace or
consolidate existing Python-heavy surfaces in `nlp-policy-nz`.

## Bottom Line

The repo already uses the right Rust-backed defaults for the hottest paths.
The survey does **not** recommend a broad dependency swap.

- Keep `msgspec` and `orjson` for serialization.
- Keep `polars` for tabular corpus work.
- Keep `lancedb` for local vector retrieval.
- Keep `spaCy` plus existing rule components as the default matching path.
- Keep `selectolax`, `DuckDB VSS`, and custom Rust/PyO3 extensions optional or
  deferred.

## Repo-Wide Matrix

| Surface | Current default | Candidate | Status | Reason |
|---|---|---|---|---|
| Serialization and validation | `msgspec` + `orjson` | `pydantic-core`, `jsonschema` | Required defaults stay as-is | Existing tracks show the current pair is fast, deterministic, and already integrated. |
| Tabular transforms | `polars` | `pandas`, `duckdb` | `polars` required | Track 59 shows the Polars core is the right Rust-backed layer for the hottest dataframe paths. |
| Vector retrieval | `lancedb` | `qdrant-client`, `duckdb` VSS, `RocksDB` | `lancedb` required; others optional or rejected | LanceDB matches the local/Arrow-oriented storage model and avoids a service dependency. |
| Grammar and rule matching | spaCy components | `nlprule` | Optional | Track 63 treated `nlprule` as an evaluation target, not a default rewrite. |
| Tokenization | Hugging Face fast tokenizers | custom Rust tokenizer crate | Deferred | Track 56 already identified span-preserving tokenization as a hotspot, but not one that needs a new crate yet. |
| Language ID | `lingua-rs` | other langid libraries | Required | Fast language ID is already part of the stack; no consolidation gain is visible from the survey. |
| HTML parsing | `beautifulsoup4` / `lxml` | `selectolax` | Optional | Use only where HTML-heavy input paths show a real bottleneck. |
| Custom acceleration | Python or Rust-backed Python | Rust/PyO3/maturin | Deferred | Keep the FFI boundary narrow until profiling proves the need. |

## Top Candidate Surfaces

1. Serialization and schema rendering.
2. Polars-native tabular operations.
3. LanceDB retrieval and local search.
4. Grammar and rule matching.
5. HTML or messy-document parsing.

These are the places where the repo already has benchmark or decision evidence
and where a substitution would have a measurable maintenance payoff.

## Explicit Rejection

`RocksDB` does not solve a current default problem in this repo. It is not a
replacement for the Parquet/Arrow corpus model, it does not replace LanceDB
vector search, and it does not simplify the existing manifest/catalog story.

## Packaging Risks

- New compiled dependencies need Windows and Linux wheel verification.
- Optional extras should not become hidden required dependencies.
- Any PyO3 or maturin path needs a narrow FFI surface and a rollback path.
- GitHub Actions must remain runnable on the fallback Python path.
