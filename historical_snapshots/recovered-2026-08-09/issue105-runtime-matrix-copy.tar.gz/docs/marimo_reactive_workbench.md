# Track 66: marimo Reactive Prototyping Workbench

Track 66 evaluates marimo as an optional reactive notebook and lightweight app
surface for corpus profiling, analysis dashboards, and reproducible legal NLP
prototyping.

## Prototype

The repo-side prototype lives at `experiments/marimo/workbench.py`.

It reads committed statistics and artifacts:

- `data/statistics/corpus_statistics_manifest.json`
- `artifacts/analysis_artifact_manifest.json`
- `docs/notebooks/*.ipynb`

The prototype stays importable without marimo installed. When marimo is
available, it builds a reactive app with summary and fixture-oriented views.

## Usage

Run the workbench with an ad hoc marimo install:

```bash
uv run --with marimo python -m experiments.marimo.workbench
```

If marimo is unavailable, the module still exposes deterministic snapshot and
Markdown helpers for tests and CI.

## Boundaries

- marimo is optional, not a required production dependency.
- The workbench reads committed repo artifacts only.
- The repo should keep analysis logic reusable outside the notebook shell.
