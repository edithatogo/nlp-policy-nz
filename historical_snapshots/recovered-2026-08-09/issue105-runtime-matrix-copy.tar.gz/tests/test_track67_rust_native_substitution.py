"""Tests for the Track 67 Rust-native substitution survey docs."""

from __future__ import annotations

from pathlib import Path


def test_track67_survey_doc_covers_core_candidates() -> None:
    """The survey doc should record the main Rust-native decisions."""
    doc = Path("docs/rust_native_pipeline_substitution.md").read_text(encoding="utf-8")

    for token in (
        "msgspec",
        "orjson",
        "polars",
        "lancedb",
        "RocksDB",
        "selectolax",
        "DuckDB",
        "PyO3",
    ):
        assert token in doc


def test_track67_dependency_policy_mentions_optional_and_rejected_paths() -> None:
    """The dependency policy matrix should reflect the survey outcome."""
    matrix = Path("conductor/dependency-policy-matrix.md").read_text(encoding="utf-8")

    assert "Rust-native" in matrix or "selectolax" in matrix
    assert "RocksDB" in matrix
