"""Track 74 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK74 = Path("conductor/archive/track74_track13_model_revisit_20260704")


def test_track74_conductor_artifacts_are_complete() -> None:
    """Track 74 keeps the expected follow-up artifacts."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK74.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK74.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK74.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK74.joinpath("index.md").read_text(encoding="utf-8")

    assert "Track 74: Revisit Track 13 legal model choices after NZ legislation fine-tuning" not in registry
    assert str(TRACK74).replace("\\", "/") not in registry
    assert metadata["track_id"] == "track74_track13_model_revisit_20260704"
    assert metadata["status"] == "archived"
    assert "Track 74: Revisit Track 13 legal model choices after NZ legislation fine-tuning" in plan
    assert "Track 74" in spec
    assert "track74_track13_model_revisit_20260704" in index
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK74.joinpath(required_file).is_file()
