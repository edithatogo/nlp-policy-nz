"""Tests for the Track 66 marimo workbench helpers."""

from __future__ import annotations

from experiments.marimo import workbench as module


def test_track66_snapshot_reads_committed_artifacts() -> None:
    snapshot = module.build_track66_workbench_snapshot()

    assert snapshot.corpus_record_count > 0
    assert snapshot.corpus_count > 0
    assert snapshot.entity_type_count > 0
    assert snapshot.analysis_artifact_count > 0
    assert snapshot.analysis_table_count > 0
    assert snapshot.analysis_figure_count > 0
    assert snapshot.analysis_diagram_count > 0
    assert snapshot.notebook_count > 0
    assert snapshot.ready_for_github_actions is True


def test_track66_module_is_importable_without_marimo_dependency() -> None:
    assert module.MARIMO_AVAILABLE is False
    assert module.app is None


def test_track66_markdown_mentions_fixture_and_artifact_sources() -> None:
    snapshot = module.build_track66_workbench_snapshot()
    markdown = module.render_track66_workbench_markdown(snapshot)

    assert "Track 66 Marimo Workbench" in markdown
    assert "corpus_statistics_manifest.json" in markdown
    assert "analysis_artifact_manifest.json" in markdown
    assert "Notebook Fixtures" in markdown
