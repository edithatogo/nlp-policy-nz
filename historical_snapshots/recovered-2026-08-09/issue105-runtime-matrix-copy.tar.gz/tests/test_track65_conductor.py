"""Track 65 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK65 = Path("conductor/archive/track65_spacy_transformers_pipeline_eval_20260701")


def test_track65_conductor_registry_and_metadata_are_complete() -> None:
    """Track 65 keeps the standard Conductor files needed for review."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK65.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK65.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK65.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK65.joinpath("index.md").read_text(encoding="utf-8")
    evidence = TRACK65.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "## [x] Track 65: spacy-transformers Pipeline Upgrade Evaluation (archived)" in registry
    assert str(TRACK65).replace("\\", "/") in registry
    assert metadata["track_id"] == "track65_spacy_transformers_pipeline_eval_20260701"
    assert metadata["status"] == "archived"
    assert "Track 65: spacy-transformers Pipeline Upgrade Evaluation" in plan
    assert "Track 65" in spec
    assert "Track 65" in index
    assert "Track 65" in evidence
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK65.joinpath(required_file).is_file()
