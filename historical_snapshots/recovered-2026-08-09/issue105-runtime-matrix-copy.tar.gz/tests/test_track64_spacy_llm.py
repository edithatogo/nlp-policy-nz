"""Tests for the Track 64 spaCy-llm annotation evaluation helpers."""

from __future__ import annotations

from nlp_policy_nz.extraction.schemas import ExtractionFamily
from nlp_policy_nz.semantic import track64_spacy_llm as module


def test_track64_backend_options_include_optional_and_local_paths() -> None:
    options = module.default_track64_backend_options()

    assert len(options) >= 4
    assert any(
        option.name == "spacy-llm" and option.requires_optional_dependency for option in options
    )
    assert any(
        option.name == "custom-prompt" and not option.requires_optional_dependency
        for option in options
    )
    assert any(option.local_inference_supported for option in options)


def test_track64_candidate_and_accepted_annotations_stay_separate() -> None:
    text = "The committee must publish the report within 20 working days."

    candidates = module.build_track64_candidate_annotations(text)
    accepted = module.build_track64_accepted_annotations(text)

    assert candidates
    assert accepted
    assert all(annotation.status == "candidate" for annotation in candidates)
    assert all(annotation.status == "accepted" for annotation in accepted)
    assert all(
        text[annotation.start : annotation.end] == annotation.text for annotation in candidates
    )
    assert all(
        text[annotation.start : annotation.end] == annotation.text for annotation in accepted
    )


def test_track64_evaluation_report_records_optional_dependency_and_local_inference() -> None:
    result = module.run_track64_evaluation()
    report = result.report

    markdown = module.render_track64_evidence_markdown(result)

    assert report.dependency_state == "optional"
    assert report.candidate_span_preservation == 1.0
    assert report.candidate_accepted_separation == 1.0
    assert report.local_inference_supported is True
    assert report.custom_prompt_supported is True
    assert report.dspy_comparison_documented is True
    assert report.review_ready is True
    assert "spaCy-llm" in markdown
    assert "custom-prompt" in markdown
    assert "vllm-offline" in markdown
    assert result.extraction_records


def test_track64_candidate_record_round_trips_to_extraction_schema() -> None:
    annotation = module.Track64AnnotationProposal(
        component_name="llm_modality",
        family=ExtractionFamily.OBLIGATION,
        label="obligation",
        text="must",
        start=4,
        end=8,
        backend="custom-prompt",
        status="candidate",
        rationale="Prompt-driven candidate mirrors the deterministic deontic cue.",
    )

    record = module.track64_candidate_to_extraction_record(
        annotation,
        source_text="The committee must act.",
        citation_path="track64/example",
    )

    assert record.family == ExtractionFamily.OBLIGATION
    assert record.attributes["status"] == "candidate"
    assert record.source_trace.citation_path == "track64/example"
