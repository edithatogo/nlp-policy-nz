"""Tests for the Track 65 spacy-transformers evaluation helpers."""

from __future__ import annotations

from nlp_policy_nz.semantic import track65_spacy_transformers as module


def test_track65_backend_options_include_transformer_and_fallback_paths() -> None:
    options = module.default_track65_backend_options()

    assert len(options) >= 4
    assert any(
        option.name == "spacy-transformers" and option.requires_optional_dependency
        for option in options
    )
    assert any(option.transformer_backed for option in options)
    assert any(option.fallback_supported for option in options)


def test_track65_candidate_and_baseline_components_preserve_token_alignment() -> None:
    text = "The committee must publish the report for Ngāi Tahu within 20 working days."

    candidates = module.build_track65_candidate_components(text)
    baseline = module.build_track65_baseline_components(text)

    assert candidates
    assert baseline
    assert all(annotation.status == "candidate" for annotation in candidates)
    assert all(annotation.status == "accepted" for annotation in baseline)
    assert all(text[annotation.start : annotation.end] == annotation.text for annotation in candidates)
    assert all(text[annotation.start : annotation.end] == annotation.text for annotation in baseline)
    assert any(annotation.text == "Ngāi Tahu" for annotation in candidates)
    assert any(annotation.text == "working days" for annotation in candidates)


def test_track65_evaluation_report_records_fallback_and_compatibility() -> None:
    result = module.run_track65_evaluation()
    report = result.report

    markdown = module.render_track65_evidence_markdown(result)

    assert report.optional_dependency_state == "optional"
    assert report.token_alignment_score == 1.0
    assert report.baseline_alignment_score == 1.0
    assert report.alignment_delta == 0.0
    assert report.maori_guard_compatibility == 1.0
    assert report.candidate_latency_seconds >= 0.0
    assert report.baseline_latency_seconds >= 0.0
    assert report.candidate_peak_kib >= 0.0
    assert report.baseline_peak_kib >= 0.0
    assert report.fallback_supported is True
    assert report.decision_written is True
    assert report.review_ready is True
    assert "spacy-transformers" in markdown
    assert "deterministic-spacy" in markdown
    assert "Candidate latency seconds" in markdown
    assert "Baseline peak KiB" in markdown
    assert "Ngāi Tahu" in markdown
