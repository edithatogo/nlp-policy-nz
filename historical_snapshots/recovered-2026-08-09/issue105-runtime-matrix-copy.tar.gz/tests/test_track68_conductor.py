"""Track 68 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK68 = Path("conductor/archive/track68_mojo_runtime_feasibility_20260701")


def test_track68_conductor_artifacts_are_complete() -> None:
    """Track 68 keeps the expected umbrella artifacts."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK68.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK68.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK68.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK68.joinpath("index.md").read_text(encoding="utf-8")
    evidence = TRACK68.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "Track 68: Mojo Runtime Feasibility for Hot Python Paths" not in registry
    assert str(TRACK68).replace("\\", "/") not in registry
    assert metadata["track_id"] == "track68_mojo_runtime_feasibility_20260701"
    assert metadata["status"] == "archived"
    assert metadata["updated_at"] == "2026-07-03T00:00:00+10:00"
    assert "Track 68: Mojo Runtime Feasibility for Hot Python Paths" in plan
    assert "- [x] Track 68 stays open as the umbrella issue and local Conductor context." in spec
    assert "track68_mojo_runtime_feasibility_20260701" in index
    assert "Track 68" in evidence
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK68.joinpath(required_file).is_file()
