"""Track 67 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK67 = Path("conductor/archive/track67_rust_native_pipeline_substitution_20260701")


def test_track67_conductor_artifacts_are_complete() -> None:
    """Track 67 keeps the expected Conductor files and survey evidence."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK67.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK67.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK67.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK67.joinpath("index.md").read_text(encoding="utf-8")
    evidence = TRACK67.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "Track 67: Rust-Native Pipeline Substitution Survey (archived) [a1beb90]" in registry
    assert str(TRACK67).replace("\\", "/") in registry
    assert metadata["track_id"] == "track67_rust_native_pipeline_substitution_20260701"
    assert metadata["status"] == "archived"
    assert "Track 67: Rust-Native Pipeline Substitution Survey" in plan
    assert "Track 67" in spec
    assert "Track 67" in index
    assert "Track 67" in evidence
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK67.joinpath(required_file).is_file()
