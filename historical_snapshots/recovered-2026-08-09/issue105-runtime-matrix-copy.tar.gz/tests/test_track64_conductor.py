"""Track 64 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK64 = Path("conductor/archive/track64_spacy_llm_annotation_eval_20260701")


def test_track64_conductor_registry_and_metadata_are_complete() -> None:
    """Track 64 keeps the standard Conductor files needed for review."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK64.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK64.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK64.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK64.joinpath("index.md").read_text(encoding="utf-8")
    evidence = TRACK64.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "## [x] Track 64: spaCy-llm Annotation Pipeline Evaluation (archived)" in registry
    assert str(TRACK64).replace("\\", "/") in registry
    assert metadata["track_id"] == "track64_spacy_llm_annotation_eval_20260701"
    assert metadata["status"] == "archived"
    assert "Track 64: spaCy-llm Annotation Pipeline Evaluation" in plan
    assert "Track 64" in spec
    assert "Track 64" in index
    assert "Track 64" in evidence
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK64.joinpath(required_file).is_file()
