"""Track 66 Conductor artifact contract tests."""

from __future__ import annotations

import json
from pathlib import Path

TRACK66 = Path("conductor/archive/track66_marimo_reactive_prototyping_20260701")


def test_track66_conductor_registry_and_metadata_are_complete() -> None:
    """Track 66 keeps the standard Conductor files needed for review."""
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")
    metadata = json.loads(TRACK66.joinpath("metadata.json").read_text(encoding="utf-8"))
    plan = TRACK66.joinpath("plan.md").read_text(encoding="utf-8")
    spec = TRACK66.joinpath("spec.md").read_text(encoding="utf-8")
    index = TRACK66.joinpath("index.md").read_text(encoding="utf-8")
    evidence = TRACK66.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "## [x] Track 66: marimo Reactive Prototyping and Evaluation Workbench (archived) [4a3626f]" in registry
    assert str(TRACK66).replace("\\", "/") in registry
    assert metadata["track_id"] == "track66_marimo_reactive_prototyping_20260701"
    assert metadata["status"] == "archived"
    assert "Track 66: marimo Reactive Prototyping and Evaluation Workbench" in plan
    assert "Track 66" in spec
    assert "Track 66" in index
    assert "Track 66" in evidence
    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK66.joinpath(required_file).is_file()
