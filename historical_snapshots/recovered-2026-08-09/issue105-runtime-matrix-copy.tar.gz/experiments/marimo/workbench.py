"""Track 66 marimo reactive prototyping workbench."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

TRACK_ID: Final[str] = "track66_marimo_reactive_prototyping_20260701"
CORPUS_MANIFEST: Final[Path] = Path("data") / "statistics" / "corpus_statistics_manifest.json"
ANALYSIS_MANIFEST: Final[Path] = Path("artifacts") / "analysis_artifact_manifest.json"
NOTEBOOKS_DIR: Final[Path] = Path("docs") / "notebooks"

try:  # pragma: no cover - optional dependency path
    import marimo as _marimo
except ImportError:  # pragma: no cover - exercised when marimo is not installed
    _marimo = None

MARIMO_AVAILABLE: Final[bool] = _marimo is not None


@dataclass(frozen=True, slots=True)
class Track66WorkbenchSnapshot:
    """Deterministic repo-side evidence for the marimo workbench."""

    repo_root: str
    marimo_available: bool
    corpus_record_count: int
    corpus_count: int
    entity_type_count: int
    analysis_artifact_count: int
    analysis_table_count: int
    analysis_figure_count: int
    analysis_diagram_count: int
    notebook_count: int
    notebook_names: tuple[str, ...]
    committed_artifact_sources: tuple[str, ...]
    ready_for_github_actions: bool


def build_track66_workbench_snapshot(
    *,
    repo_root_path: Path | str | None = None,
) -> Track66WorkbenchSnapshot:
    """Build a deterministic snapshot from committed statistics and artifacts."""
    root = Path(repo_root_path) if repo_root_path is not None else _repo_root()
    corpus_manifest = _read_json(root / CORPUS_MANIFEST)
    analysis_manifest = _read_json(root / ANALYSIS_MANIFEST)
    notebooks = sorted(path.name for path in (root / NOTEBOOKS_DIR).glob("*.ipynb"))
    committed_sources = (
        str(CORPUS_MANIFEST).replace("\\", "/"),
        str(ANALYSIS_MANIFEST).replace("\\", "/"),
        *(f"docs/notebooks/{name}" for name in notebooks),
    )
    analysis_summary = analysis_manifest.get("summary", {})
    corpus_summary = corpus_manifest.get("summary", {})
    ready_for_github_actions = bool(notebooks) and bool(corpus_manifest) and bool(analysis_manifest)
    return Track66WorkbenchSnapshot(
        repo_root=str(root),
        marimo_available=MARIMO_AVAILABLE,
        corpus_record_count=int(corpus_summary.get("record_count", 0)),
        corpus_count=int(corpus_summary.get("corpus_count", 0)),
        entity_type_count=int(corpus_summary.get("entity_type_count", 0)),
        analysis_artifact_count=int(analysis_summary.get("available_count", 0)),
        analysis_table_count=int(analysis_summary.get("table_count", 0)),
        analysis_figure_count=int(analysis_summary.get("figure_count", 0)),
        analysis_diagram_count=int(analysis_summary.get("diagram_count", 0)),
        notebook_count=len(notebooks),
        notebook_names=tuple(notebooks),
        committed_artifact_sources=committed_sources,
        ready_for_github_actions=ready_for_github_actions,
    )


def render_track66_workbench_markdown(snapshot: Track66WorkbenchSnapshot) -> str:
    """Render the Track 66 workbench snapshot as Markdown."""
    notebook_list = "\n".join(f"- `{name}`" for name in snapshot.notebook_names) or "- none"
    sources = "\n".join(
        f"- `{source}`" for source in snapshot.committed_artifact_sources
    )
    return "\n".join(
        [
            "# Track 66 Marimo Workbench",
            "",
            "## Summary",
            "",
            "Track 66 evaluates marimo as a reactive prototyping surface for repo-side corpus profiling and analysis dashboards.",
            "",
            "## Evidence",
            "",
            f"- marimo installed: {'yes' if snapshot.marimo_available else 'no'}",
            f"- Corpus records: {snapshot.corpus_record_count}",
            f"- Corpora represented: {snapshot.corpus_count}",
            f"- Entity types: {snapshot.entity_type_count}",
            f"- Analysis artifacts: {snapshot.analysis_artifact_count}",
            f"- Tables: {snapshot.analysis_table_count}",
            f"- Figures: {snapshot.analysis_figure_count}",
            f"- Diagrams: {snapshot.analysis_diagram_count}",
            f"- Notebook fixtures: {snapshot.notebook_count}",
            f"- GitHub Actions ready: {'yes' if snapshot.ready_for_github_actions else 'no'}",
            "",
            "## Committed Inputs",
            "",
            sources,
            "",
            "## Notebook Fixtures",
            "",
            notebook_list,
            "",
            "## Boundary",
            "",
            "marimo stays optional, and the deterministic fixture-backed snapshots remain the source of truth for CI and review.",
            "",
        ]
    )


def create_track66_app(
    *,
    repo_root_path: Path | str | None = None,
) -> Any:  # noqa: ANN401 - marimo App is optional and dynamically typed
    """Create the marimo app when the dependency is available."""
    if _marimo is None:
        return None

    mo = _marimo
    app = mo.App(width="medium")
    root = Path(repo_root_path) if repo_root_path is not None else _repo_root()

    @app.cell
    def _():
        import marimo as mo  # type: ignore[import-not-found]

        return (mo,)

    @app.cell
    def _():
        snapshot = build_track66_workbench_snapshot(repo_root_path=root)
        return (snapshot,)

    @app.cell
    def _(mo, snapshot):
        mode = mo.ui.dropdown(
            options=[
                "summary",
                "fixtures",
                "inputs",
            ],
            value="summary",
            label="Workbench view",
        )
        return (mode,)

    @app.cell(hide_code=True)
    def _(mo, snapshot, mode):
        if mode.value == "summary":
            return mo.md(render_track66_workbench_markdown(snapshot))
        if mode.value == "fixtures":
            return mo.md(
                "\n".join(
                    [
                        "# Fixture inventory",
                        "",
                        *(f"- `{name}`" for name in snapshot.notebook_names),
                    ]
                ),
            )
        return mo.md(
            "\n".join(
                [
                    "# Input boundary",
                    "",
                    "The workbench reads only committed corpus statistics, analysis artifacts, and notebook fixtures.",
                ]
            ),
        )

    return app


app = create_track66_app()


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


if __name__ == "__main__":  # pragma: no cover - manual app entrypoint
    if app is None:
        raise ImportError(
            "marimo is not installed. Run `uv run --with marimo python -m experiments.marimo.workbench`.",
        )
    app.run()


__all__ = [
    "MARIMO_AVAILABLE",
    "TRACK_ID",
    "Track66WorkbenchSnapshot",
    "app",
    "build_track66_workbench_snapshot",
    "create_track66_app",
    "render_track66_workbench_markdown",
]
