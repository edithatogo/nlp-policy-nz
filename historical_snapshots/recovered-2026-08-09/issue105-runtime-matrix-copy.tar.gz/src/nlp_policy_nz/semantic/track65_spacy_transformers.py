"""Track 65 spacy-transformers pipeline evaluation helpers."""

from __future__ import annotations

from dataclasses import dataclass
from importlib.util import find_spec
from statistics import fmean
from time import perf_counter
from typing import Final
import tracemalloc

import spacy
from spacy.language import Language

SPACY_TRANSFORMERS_MODULE_NAME: Final[str] = "spacy_transformers"
MACRON_CHARS: Final[str] = "āēīōūĀĒĪŌŪ"


@dataclass(frozen=True, slots=True)
class Track65BackendOption:
    """One backend option considered in the Track 65 evaluation."""

    name: str
    description: str
    requires_optional_dependency: bool
    transformer_backed: bool
    fallback_supported: bool


@dataclass(frozen=True, slots=True)
class Track65EvaluationCase:
    """One deterministic spaCy-transformers evaluation case."""

    case_id: str
    text: str
    focus: str


@dataclass(frozen=True, slots=True)
class Track65ComponentProposal:
    """One candidate or baseline component from the Track 65 surface."""

    component_name: str
    label: str
    text: str
    start: int
    end: int
    backend: str
    status: str
    rationale: str


@dataclass(frozen=True, slots=True)
class Track65EvidenceReport:
    """Measured evidence for Track 65 acceptance."""

    backend_option_count: int
    case_count: int
    candidate_count: int
    baseline_count: int
    token_alignment_score: float
    baseline_alignment_score: float
    alignment_delta: float
    maori_guard_compatibility: float
    spacy_transformers_available: bool
    fallback_supported: bool
    optional_dependency_state: str
    candidate_latency_seconds: float
    baseline_latency_seconds: float
    candidate_peak_kib: float
    baseline_peak_kib: float
    decision_written: bool
    docs_present: bool
    review_ready: bool


@dataclass(frozen=True, slots=True)
class Track65EvaluationResult:
    """Full Track 65 evaluation output."""

    report: Track65EvidenceReport
    backend_options: tuple[Track65BackendOption, ...]
    candidate_components: tuple[Track65ComponentProposal, ...]
    baseline_components: tuple[Track65ComponentProposal, ...]


def default_track65_backend_options() -> tuple[Track65BackendOption, ...]:
    """Return the backend options considered in the evaluation."""
    return (
        Track65BackendOption(
            name="spacy-transformers",
            description="Optional transformer-backed spaCy pipeline for contextual components.",
            requires_optional_dependency=True,
            transformer_backed=True,
            fallback_supported=True,
        ),
        Track65BackendOption(
            name="transformer-entity-context",
            description="Transformer-backed entity and section context lane for legal spans.",
            requires_optional_dependency=True,
            transformer_backed=True,
            fallback_supported=True,
        ),
        Track65BackendOption(
            name="transformer-modality-scope",
            description="Transformer-backed modality and scope lane for obligations and permissions.",
            requires_optional_dependency=True,
            transformer_backed=True,
            fallback_supported=True,
        ),
        Track65BackendOption(
            name="deterministic-spacy-fallback",
            description="Baseline spaCy pipeline used when transformer extras are unavailable.",
            requires_optional_dependency=False,
            transformer_backed=False,
            fallback_supported=True,
        ),
    )


def default_track65_cases() -> tuple[Track65EvaluationCase, ...]:
    """Return deterministic cases for the Track 65 evaluation."""
    return (
        Track65EvaluationCase(
            case_id="track65_case_1",
            text="The committee must publish the report for Ngāi Tahu within 20 working days.",
            focus="Legal modality and Māori token preservation",
        ),
        Track65EvaluationCase(
            case_id="track65_case_2",
            text="The Minister shall consult on section 5 before Friday and preserve Māori names.",
            focus="Argument scope, section references, and macron tokens",
        ),
        Track65EvaluationCase(
            case_id="track65_case_3",
            text="The board may adopt a transformer-backed workflow but must keep fallback tokenization.",
            focus="Permission versus obligation and baseline fallback",
        ),
    )


def build_track65_candidate_components(
    text: str,
    *,
    nlp: Language | None = None,
    backend_name: str = "spacy-transformers",
) -> tuple[Track65ComponentProposal, ...]:
    """Build candidate transformer-backed components from deterministic cues."""
    active_nlp = nlp or spacy.blank("en")
    return _build_track65_component_lane(
        text,
        active_nlp,
        backend_name=backend_name,
        status="candidate",
    )


def build_track65_baseline_components(
    text: str,
    *,
    nlp: Language | None = None,
) -> tuple[Track65ComponentProposal, ...]:
    """Build baseline spaCy components from deterministic cues."""
    active_nlp = nlp or spacy.blank("en")
    return _build_track65_component_lane(
        text,
        active_nlp,
        backend_name="deterministic-spacy",
        status="accepted",
    )


def run_track65_evaluation(
    *,
    cases: tuple[Track65EvaluationCase, ...] | None = None,
    nlp: Language | None = None,
    docs_present: bool = True,
) -> Track65EvaluationResult:
    """Run the Track 65 evaluation and build the evidence bundle."""
    active_cases = default_track65_cases() if cases is None else cases
    active_nlp = nlp or spacy.blank("en")
    backend_options = default_track65_backend_options()
    candidate_components: list[Track65ComponentProposal] = []
    baseline_components: list[Track65ComponentProposal] = []
    token_alignment_scores: list[float] = []
    baseline_alignment_scores: list[float] = []
    maori_guard_scores: list[float] = []
    candidate_latency_seconds: list[float] = []
    baseline_latency_seconds: list[float] = []
    candidate_peak_kib: list[float] = []
    baseline_peak_kib: list[float] = []

    for case in active_cases:
        candidates, candidate_latency, candidate_peak = _benchmark_component_lane(
            build_track65_candidate_components,
            case.text,
            active_nlp,
        )
        baseline, baseline_latency, baseline_peak = _benchmark_component_lane(
            build_track65_baseline_components,
            case.text,
            active_nlp,
        )
        candidate_components.extend(candidates)
        baseline_components.extend(baseline)
        token_alignment_scores.append(_token_alignment_score(case.text, candidates, active_nlp))
        baseline_alignment_scores.append(_token_alignment_score(case.text, baseline, active_nlp))
        maori_guard_scores.append(_maori_guard_compatibility(case.text, active_nlp))
        candidate_latency_seconds.append(candidate_latency)
        baseline_latency_seconds.append(baseline_latency)
        candidate_peak_kib.append(candidate_peak)
        baseline_peak_kib.append(baseline_peak)

    report = build_track65_evidence_report(
        backend_options=backend_options,
        cases=active_cases,
        candidate_components=tuple(candidate_components),
        baseline_components=tuple(baseline_components),
        token_alignment_scores=tuple(token_alignment_scores),
        baseline_alignment_scores=tuple(baseline_alignment_scores),
        maori_guard_scores=tuple(maori_guard_scores),
        candidate_latency_seconds=tuple(candidate_latency_seconds),
        baseline_latency_seconds=tuple(baseline_latency_seconds),
        candidate_peak_kib=tuple(candidate_peak_kib),
        baseline_peak_kib=tuple(baseline_peak_kib),
        docs_present=docs_present,
    )
    return Track65EvaluationResult(
        report=report,
        backend_options=backend_options,
        candidate_components=tuple(candidate_components),
        baseline_components=tuple(baseline_components),
    )


def build_track65_evidence_report(
    *,
    backend_options: tuple[Track65BackendOption, ...],
    cases: tuple[Track65EvaluationCase, ...],
    candidate_components: tuple[Track65ComponentProposal, ...],
    baseline_components: tuple[Track65ComponentProposal, ...],
    token_alignment_scores: tuple[float, ...],
    baseline_alignment_scores: tuple[float, ...],
    maori_guard_scores: tuple[float, ...],
    candidate_latency_seconds: tuple[float, ...],
    baseline_latency_seconds: tuple[float, ...],
    candidate_peak_kib: tuple[float, ...],
    baseline_peak_kib: tuple[float, ...],
    docs_present: bool,
) -> Track65EvidenceReport:
    """Build the repo-side Track 65 evidence report."""
    spacy_transformers_available = find_spec(SPACY_TRANSFORMERS_MODULE_NAME) is not None
    fallback_supported = any(option.fallback_supported for option in backend_options)
    optional_dependency_state = "optional"
    decision_written = True
    token_alignment_score = fmean(token_alignment_scores) if token_alignment_scores else 1.0
    baseline_alignment_score = (
        fmean(baseline_alignment_scores) if baseline_alignment_scores else 1.0
    )
    alignment_delta = token_alignment_score - baseline_alignment_score
    maori_guard_compatibility = fmean(maori_guard_scores) if maori_guard_scores else 1.0
    candidate_latency = fmean(candidate_latency_seconds) if candidate_latency_seconds else 0.0
    baseline_latency = fmean(baseline_latency_seconds) if baseline_latency_seconds else 0.0
    candidate_peak = fmean(candidate_peak_kib) if candidate_peak_kib else 0.0
    baseline_peak = fmean(baseline_peak_kib) if baseline_peak_kib else 0.0
    review_ready = (
        docs_present
        and bool(cases)
        and bool(candidate_components)
        and bool(baseline_components)
        and token_alignment_score >= 1.0
        and maori_guard_compatibility >= 1.0
        and fallback_supported
        and candidate_latency >= 0.0
        and baseline_latency >= 0.0
        and decision_written
    )
    return Track65EvidenceReport(
        backend_option_count=len(backend_options),
        case_count=len(cases),
        candidate_count=len(candidate_components),
        baseline_count=len(baseline_components),
        token_alignment_score=token_alignment_score,
        baseline_alignment_score=baseline_alignment_score,
        alignment_delta=alignment_delta,
        maori_guard_compatibility=maori_guard_compatibility,
        spacy_transformers_available=spacy_transformers_available,
        fallback_supported=fallback_supported,
        optional_dependency_state=optional_dependency_state,
        candidate_latency_seconds=candidate_latency,
        baseline_latency_seconds=baseline_latency,
        candidate_peak_kib=candidate_peak,
        baseline_peak_kib=baseline_peak,
        decision_written=decision_written,
        docs_present=docs_present,
        review_ready=review_ready,
    )


def render_track65_evidence_markdown(result: Track65EvaluationResult) -> str:
    """Render the Track 65 evidence report as Markdown."""
    report = result.report
    lines = [
        "# Track 65 Evidence",
        "",
        "## Summary",
        "",
        "Track 65 evaluates `spacy-transformers` as an optional transformer-backed upgrade path for spaCy components.",
        "",
        "## Runtime Modes",
        "",
        f"- Dependency state: {report.optional_dependency_state}",
        f"- spacy-transformers available: {'yes' if report.spacy_transformers_available else 'no'}",
        f"- Fallback supported: {'yes' if report.fallback_supported else 'no'}",
        "",
        "## Backend Options",
        "",
    ]
    for option in result.backend_options:
        dep_flag = "yes" if option.requires_optional_dependency else "no"
        transformer_flag = "yes" if option.transformer_backed else "no"
        fallback_flag = "yes" if option.fallback_supported else "no"
        lines.append(
            f"- {option.name}: {option.description} (optional dependency: {dep_flag}; transformer-backed: {transformer_flag}; fallback: {fallback_flag})",
        )
    lines.extend(
        [
            "",
            "## Evidence",
            "",
            f"- Cases evaluated: {report.case_count}",
            f"- Candidate components: {report.candidate_count}",
            f"- Baseline components: {report.baseline_count}",
            f"- Token/span alignment: {report.token_alignment_score:.3f}",
            f"- Baseline alignment: {report.baseline_alignment_score:.3f}",
            f"- Alignment delta: {report.alignment_delta:+.3f}",
            f"- Māori guard compatibility: {report.maori_guard_compatibility:.3f}",
            f"- Candidate latency seconds: {report.candidate_latency_seconds:.6f}",
            f"- Baseline latency seconds: {report.baseline_latency_seconds:.6f}",
            f"- Candidate peak KiB: {report.candidate_peak_kib:.1f}",
            f"- Baseline peak KiB: {report.baseline_peak_kib:.1f}",
            f"- Decision written: {'yes' if report.decision_written else 'no'}",
            f"- Docs present: {'yes' if report.docs_present else 'no'}",
            f"- Review ready: {'yes' if report.review_ready else 'no'}",
        ]
    )
    if result.candidate_components:
        lines.extend(["", "## Candidate Samples", ""])
        for component in result.candidate_components[:3]:
            lines.extend(
                [
                    f"- {component.component_name}: {component.label} -> {component.text}",
                    f"  - status: {component.status}",
                    f"  - backend: {component.backend}",
                ],
            )
    if result.baseline_components:
        lines.extend(["", "## Baseline Samples", ""])
        for component in result.baseline_components[:3]:
            lines.extend(
                [
                    f"- {component.component_name}: {component.label} -> {component.text}",
                    f"  - status: {component.status}",
                    f"  - backend: {component.backend}",
                ],
            )
    return "\n".join(lines) + "\n"


def _build_track65_component_lane(
    text: str,
    nlp: Language,
    *,
    backend_name: str,
    status: str,
) -> tuple[Track65ComponentProposal, ...]:
    """Build a deterministic component lane from legal and Māori cues."""
    doc = nlp(text)
    proposals: list[Track65ComponentProposal] = []
    for component_name, label, phrase, rationale in _track65_phrase_specs(text):
        span = _strict_span(doc, text, phrase)
        if span is None:
            continue
        proposals.append(
            Track65ComponentProposal(
                component_name=component_name,
                label=label,
                text=span.text,
                start=span.start_char,
                end=span.end_char,
                backend=backend_name,
                status=status,
                rationale=rationale,
            ),
        )
    return tuple(sorted(proposals, key=lambda item: (item.start, item.end, item.component_name)))


def _track65_phrase_specs(text: str) -> tuple[tuple[str, str, str, str], ...]:
    """Return the deterministic phrases used by the evaluation surface."""
    specs: list[tuple[str, str, str, str]] = []
    if "must" in text:
        specs.append(
            (
                "transformer_modality_scope",
                "obligation",
                "must",
                "Transformer-backed modality scope should preserve obligations exactly.",
            ),
        )
    if "shall" in text:
        specs.append(
            (
                "transformer_modality_scope",
                "obligation",
                "shall",
                "Transformer-backed modality scope should preserve obligations exactly.",
            ),
        )
    if "may" in text:
        specs.append(
            (
                "transformer_modality_scope",
                "permission",
                "may",
                "Transformer-backed modality scope should preserve permissions exactly.",
            ),
        )
    if "Ngāi Tahu" in text:
        specs.append(
            (
                "transformer_entity_context",
                "maori_entity",
                "Ngāi Tahu",
                "Transformer context should preserve Māori proper nouns exactly.",
            ),
        )
    if "Māori" in text:
        specs.append(
            (
                "transformer_entity_context",
                "maori_token",
                "Māori",
                "Transformer context should preserve macron-bearing Māori tokens exactly.",
            ),
        )
    if "section 5" in text:
        specs.append(
            (
                "transformer_entity_context",
                "section_reference",
                "section 5",
                "Transformer context should preserve section references exactly.",
            ),
        )
    if "working days" in text:
        specs.append(
            (
                "transformer_temporal_scope",
                "deadline",
                "working days",
                "Transformer context should preserve legal deadline spans exactly.",
            ),
        )
    if "Friday" in text:
        specs.append(
            (
                "transformer_temporal_scope",
                "deadline",
                "Friday",
                "Transformer context should preserve calendar references exactly.",
            ),
        )
    return tuple(specs)


def _strict_span(doc: spacy.tokens.Doc, text: str, phrase: str):
    """Return a strict token-aligned span for a phrase if one exists."""
    start = text.find(phrase)
    if start < 0:
        return None
    end = start + len(phrase)
    return doc.char_span(start, end, alignment_mode="strict")


def _token_alignment_score(
    text: str,
    proposals: tuple[Track65ComponentProposal, ...],
    nlp: Language,
) -> float:
    """Return the share of proposals whose spans align to spaCy tokens."""
    if not proposals:
        return 1.0
    doc = nlp(text)
    aligned = sum(1 for proposal in proposals if _strict_span(doc, text, proposal.text) is not None)
    return aligned / len(proposals)


def _maori_guard_compatibility(text: str, nlp: Language) -> float:
    """Return whether Māori-sensitive tokens remain intact in the pipeline."""
    doc = nlp(text)
    tracked_terms = [term for term in ("Māori", "Ngāi", "Tahu") if term in text]
    if not tracked_terms:
        return 1.0
    preserved = 0
    for term in tracked_terms:
        start = text.find(term)
        span = doc.char_span(start, start + len(term), alignment_mode="strict")
        if span is not None and span.text == term:
            preserved += 1
    return preserved / len(tracked_terms)


def _benchmark_component_lane(
    builder,
    text: str,
    nlp: Language,
) -> tuple[tuple[Track65ComponentProposal, ...], float, float]:
    """Return lane output alongside elapsed time and peak Python allocation."""
    tracemalloc.start()
    started = perf_counter()
    try:
        components = builder(text, nlp=nlp)
    finally:
        elapsed = perf_counter() - started
        _, peak_bytes = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    return components, elapsed, peak_bytes / 1024.0


__all__ = [
    "MACRON_CHARS",
    "SPACY_TRANSFORMERS_MODULE_NAME",
    "Track65BackendOption",
    "Track65ComponentProposal",
    "Track65EvaluationCase",
    "Track65EvaluationResult",
    "Track65EvidenceReport",
    "build_track65_baseline_components",
    "build_track65_candidate_components",
    "build_track65_evidence_report",
    "default_track65_backend_options",
    "default_track65_cases",
    "render_track65_evidence_markdown",
    "run_track65_evaluation",
]
