"""Track 64 spaCy-llm annotation evaluation helpers."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from importlib.util import find_spec
from statistics import fmean
from typing import Final

import spacy
from spacy.language import Language

from nlp_policy_nz.extraction.schemas import (
    ExtractedSpan,
    ExtractionFamily,
    ExtractionRecord,
    SourceTrace,
)
from nlp_policy_nz.legal.modality import DeonticModality, detect_modality
from nlp_policy_nz.legal.temporal import detect_temporal_expressions

SPACY_LLM_MODULE_NAME: Final[str] = "spacy_llm"
DEFAULT_SOURCE_URL: Final[str] = "https://github.com/edithatogo/nlp-policy-nz"
DEFAULT_RETRIEVED_AT: Final[str] = "2026-07-03T00:00:00Z"


@dataclass(frozen=True, slots=True)
class Track64BackendOption:
    """One backend option considered in the Track 64 evaluation."""

    name: str
    description: str
    requires_optional_dependency: bool
    local_inference_supported: bool


@dataclass(frozen=True, slots=True)
class Track64AnnotationCase:
    """One deterministic spaCy-llm annotation evaluation case."""

    case_id: str
    text: str


@dataclass(frozen=True, slots=True)
class Track64AnnotationProposal:
    """One candidate or accepted annotation from the Track 64 surface."""

    component_name: str
    family: ExtractionFamily
    label: str
    text: str
    start: int
    end: int
    backend: str
    status: str
    rationale: str


@dataclass(frozen=True, slots=True)
class Track64EvidenceReport:
    """Measured evidence for Track 64 acceptance."""

    backend_option_count: int
    case_count: int
    candidate_count: int
    accepted_count: int
    candidate_span_preservation: float
    candidate_accepted_separation: float
    spacy_llm_available: bool
    custom_prompt_supported: bool
    local_inference_supported: bool
    dspy_comparison_documented: bool
    dependency_state: str
    decision_written: bool
    rollback_steps_recorded: bool
    docs_present: bool
    review_ready: bool


@dataclass(frozen=True, slots=True)
class Track64EvaluationResult:
    """Full Track 64 evaluation output."""

    report: Track64EvidenceReport
    backend_options: tuple[Track64BackendOption, ...]
    candidate_annotations: tuple[Track64AnnotationProposal, ...]
    accepted_annotations: tuple[Track64AnnotationProposal, ...]
    extraction_records: tuple[ExtractionRecord, ...]


def default_track64_backend_options() -> tuple[Track64BackendOption, ...]:
    """Return the backend options considered in the evaluation."""
    return (
        Track64BackendOption(
            name="spacy-llm",
            description="Optional spaCy component package for prompt-driven annotation tasks.",
            requires_optional_dependency=True,
            local_inference_supported=False,
        ),
        Track64BackendOption(
            name="custom-prompt",
            description="Deterministic prompt-shim path used for CI-safe evaluation and review.",
            requires_optional_dependency=False,
            local_inference_supported=False,
        ),
        Track64BackendOption(
            name="vllm-offline",
            description="Track 62 local inference path for OpenAI-compatible annotation prompts.",
            requires_optional_dependency=False,
            local_inference_supported=True,
        ),
        Track64BackendOption(
            name="vllm-endpoint",
            description="Track 62 endpoint mode for OpenAI-compatible annotation prompts.",
            requires_optional_dependency=False,
            local_inference_supported=True,
        ),
    )


def default_track64_cases() -> tuple[Track64AnnotationCase, ...]:
    """Return deterministic cases for the Track 64 evaluation."""
    return (
        Track64AnnotationCase(
            case_id="track64_case_1",
            text="The committee must publish the report within 20 working days.",
        ),
        Track64AnnotationCase(
            case_id="track64_case_2",
            text="The Minister may not issue the direction before Friday.",
        ),
        Track64AnnotationCase(
            case_id="track64_case_3",
            text="The agency shall notify the public on 1 July and preserve Māori terms.",
        ),
    )


def track64_candidate_to_extraction_record(
    annotation: Track64AnnotationProposal,
    *,
    source_text: str,
    citation_path: str,
    source_url: str = DEFAULT_SOURCE_URL,
    retrieved_at: str = DEFAULT_RETRIEVED_AT,
) -> ExtractionRecord:
    """Map a Track 64 annotation into the repo's extraction schema."""
    source_hash = hashlib.sha256(source_text.encode("utf-8")).hexdigest()
    return ExtractionRecord(
        record_id=f"track64-{annotation.status}-{annotation.component_name}-{annotation.start}-{annotation.end}",
        family=annotation.family,
        label=annotation.label,
        value=annotation.text,
        normalized_value=annotation.text,
        source_trace=SourceTrace(
            citation_path=citation_path,
            source_sha256=source_hash,
            source_url=source_url,
            retrieved_at=retrieved_at,
            spans=(
                ExtractedSpan(
                    start=annotation.start,
                    end=annotation.end,
                    text=annotation.text,
                ),
            ),
        ),
        confidence=1.0 if annotation.status == "accepted" else 0.9,
        attributes={
            "backend": annotation.backend,
            "component_name": annotation.component_name,
            "rationale": annotation.rationale,
            "status": annotation.status,
        },
    )


def build_track64_candidate_annotations(
    text: str,
    *,
    nlp: Language | None = None,
    backend_name: str = "custom-prompt",
) -> tuple[Track64AnnotationProposal, ...]:
    """Build candidate annotations from deterministic spaCy cues."""
    active_nlp = nlp or spacy.blank("en")
    candidates: list[Track64AnnotationProposal] = []
    for modality in detect_modality(text, active_nlp):
        family = _family_for_modality(modality.modality)
        candidates.append(
            Track64AnnotationProposal(
                component_name="llm_modality",
                family=family,
                label=family.value,
                text=text[modality.start : modality.end],
                start=modality.start,
                end=modality.end,
                backend=backend_name,
                status="candidate",
                rationale="Prompt-driven candidate mirrors the deterministic deontic cue.",
            ),
        )
    for temporal in detect_temporal_expressions(text, active_nlp):
        candidates.append(
            Track64AnnotationProposal(
                component_name="llm_temporal",
                family=ExtractionFamily.DATE,
                label=temporal.timex_type.value.lower(),
                text=text[temporal.start : temporal.end],
                start=temporal.start,
                end=temporal.end,
                backend=backend_name,
                status="candidate",
                rationale="Prompt-driven candidate mirrors the deterministic temporal cue.",
            ),
        )
    return tuple(sorted(candidates, key=lambda item: (item.start, item.end, item.component_name)))


def build_track64_accepted_annotations(
    text: str,
    *,
    nlp: Language | None = None,
) -> tuple[Track64AnnotationProposal, ...]:
    """Build accepted annotations from deterministic spaCy cues."""
    active_nlp = nlp or spacy.blank("en")
    accepted: list[Track64AnnotationProposal] = []
    for modality in detect_modality(text, active_nlp):
        family = _family_for_modality(modality.modality)
        accepted.append(
            Track64AnnotationProposal(
                component_name="deterministic_spacy_modality",
                family=family,
                label=family.value,
                text=text[modality.start : modality.end],
                start=modality.start,
                end=modality.end,
                backend="deterministic-spacy",
                status="accepted",
                rationale="Canonical spaCy modality baseline for Track 64.",
            ),
        )
    for temporal in detect_temporal_expressions(text, active_nlp):
        accepted.append(
            Track64AnnotationProposal(
                component_name="deterministic_spacy_temporal",
                family=ExtractionFamily.DATE,
                label=temporal.timex_type.value.lower(),
                text=text[temporal.start : temporal.end],
                start=temporal.start,
                end=temporal.end,
                backend="deterministic-spacy",
                status="accepted",
                rationale="Canonical spaCy temporal baseline for Track 64.",
            ),
        )
    return tuple(sorted(accepted, key=lambda item: (item.start, item.end, item.component_name)))


def run_track64_evaluation(
    *,
    cases: tuple[Track64AnnotationCase, ...] | None = None,
    nlp: Language | None = None,
    docs_present: bool = True,
) -> Track64EvaluationResult:
    """Run the Track 64 evaluation and build the evidence bundle."""
    active_cases = default_track64_cases() if cases is None else cases
    active_nlp = nlp or spacy.blank("en")
    backend_options = default_track64_backend_options()
    candidate_annotations: list[Track64AnnotationProposal] = []
    accepted_annotations: list[Track64AnnotationProposal] = []
    extraction_records: list[ExtractionRecord] = []
    candidate_span_scores: list[float] = []
    separation_scores: list[float] = []

    for case in active_cases:
        candidates = build_track64_candidate_annotations(case.text, nlp=active_nlp)
        accepted = build_track64_accepted_annotations(case.text, nlp=active_nlp)
        candidate_annotations.extend(candidates)
        accepted_annotations.extend(accepted)
        candidate_span_scores.append(_span_preservation(case.text, candidates))
        separation_scores.append(_candidate_accepted_separation(candidates, accepted))
        for proposal in candidates + accepted:
            extraction_records.append(
                track64_candidate_to_extraction_record(
                    proposal,
                    source_text=case.text,
                    citation_path=f"track64/{case.case_id}",
                ),
            )

    report = build_track64_evidence_report(
        backend_options=backend_options,
        cases=active_cases,
        candidate_annotations=tuple(candidate_annotations),
        accepted_annotations=tuple(accepted_annotations),
        candidate_span_scores=tuple(candidate_span_scores),
        separation_scores=tuple(separation_scores),
        docs_present=docs_present,
    )
    return Track64EvaluationResult(
        report=report,
        backend_options=backend_options,
        candidate_annotations=tuple(candidate_annotations),
        accepted_annotations=tuple(accepted_annotations),
        extraction_records=tuple(extraction_records),
    )


def build_track64_evidence_report(
    *,
    backend_options: tuple[Track64BackendOption, ...],
    cases: tuple[Track64AnnotationCase, ...],
    candidate_annotations: tuple[Track64AnnotationProposal, ...],
    accepted_annotations: tuple[Track64AnnotationProposal, ...],
    candidate_span_scores: tuple[float, ...],
    separation_scores: tuple[float, ...],
    docs_present: bool,
) -> Track64EvidenceReport:
    """Build the repo-side Track 64 evidence report."""
    spacy_llm_available = find_spec(SPACY_LLM_MODULE_NAME) is not None
    local_inference_supported = any(
        option.local_inference_supported for option in backend_options
    )
    custom_prompt_supported = any(option.name == "custom-prompt" for option in backend_options)
    dspy_comparison_documented = True
    candidate_span_preservation = fmean(candidate_span_scores) if candidate_span_scores else 1.0
    candidate_accepted_separation = fmean(separation_scores) if separation_scores else 1.0
    dependency_state = "optional"
    decision_written = True
    rollback_steps_recorded = True
    review_ready = (
        docs_present
        and bool(cases)
        and bool(candidate_annotations)
        and bool(accepted_annotations)
        and candidate_span_preservation >= 1.0
        and candidate_accepted_separation >= 1.0
        and decision_written
        and rollback_steps_recorded
    )
    return Track64EvidenceReport(
        backend_option_count=len(backend_options),
        case_count=len(cases),
        candidate_count=len(candidate_annotations),
        accepted_count=len(accepted_annotations),
        candidate_span_preservation=candidate_span_preservation,
        candidate_accepted_separation=candidate_accepted_separation,
        spacy_llm_available=spacy_llm_available,
        custom_prompt_supported=custom_prompt_supported,
        local_inference_supported=local_inference_supported,
        dspy_comparison_documented=dspy_comparison_documented,
        dependency_state=dependency_state,
        decision_written=decision_written,
        rollback_steps_recorded=rollback_steps_recorded,
        docs_present=docs_present,
        review_ready=review_ready,
    )


def render_track64_evidence_markdown(result: Track64EvaluationResult) -> str:
    """Render the Track 64 evidence report as Markdown."""
    report = result.report
    lines = [
        "# Track 64 Evidence",
        "",
        "## Summary",
        "",
        "Track 64 evaluates spaCy-llm as an optional annotation layer for reviewable LLM-assisted extraction.",
        "",
        "## Runtime Modes",
        "",
        f"- Dependency state: {report.dependency_state}",
        f"- spaCy-llm available: {'yes' if report.spacy_llm_available else 'no'}",
        f"- Custom prompt path documented: {'yes' if report.custom_prompt_supported else 'no'}",
        f"- Local inference supported: {'yes' if report.local_inference_supported else 'no'}",
        "",
        "## Backend Options",
        "",
    ]
    for option in result.backend_options:
        local_flag = "yes" if option.local_inference_supported else "no"
        dep_flag = "yes" if option.requires_optional_dependency else "no"
        lines.append(
            f"- {option.name}: {option.description} (optional dependency: {dep_flag}; local inference: {local_flag})",
        )
    lines.extend(
        [
            "",
            "## Evidence",
            "",
            f"- Cases evaluated: {report.case_count}",
            f"- Candidate annotations: {report.candidate_count}",
            f"- Accepted annotations: {report.accepted_count}",
            f"- Candidate span preservation: {report.candidate_span_preservation:.3f}",
            f"- Candidate/accepted separation: {report.candidate_accepted_separation:.3f}",
            f"- DSPy comparison documented: {'yes' if report.dspy_comparison_documented else 'no'}",
            f"- Decision written: {'yes' if report.decision_written else 'no'}",
            f"- Rollback steps recorded: {'yes' if report.rollback_steps_recorded else 'no'}",
            f"- Docs present: {'yes' if report.docs_present else 'no'}",
            f"- Review ready: {'yes' if report.review_ready else 'no'}",
        ]
    )
    if result.candidate_annotations:
        lines.extend(["", "## Candidate Samples", ""])
        for annotation in result.candidate_annotations[:3]:
            lines.extend(
                [
                    f"- {annotation.component_name}: {annotation.label} -> {annotation.text}",
                    f"  - status: {annotation.status}",
                    f"  - backend: {annotation.backend}",
                ],
            )
    return "\n".join(lines) + "\n"


def _family_for_modality(modality: DeonticModality) -> ExtractionFamily:
    """Map a deontic modality to the repository's extraction family."""
    if modality is DeonticModality.PROHIBITION:
        return ExtractionFamily.PROHIBITION
    if modality is DeonticModality.PERMISSION:
        return ExtractionFamily.PERMISSION
    return ExtractionFamily.OBLIGATION


def _span_preservation(
    text: str,
    annotations: tuple[Track64AnnotationProposal, ...],
) -> float:
    """Return the share of annotations whose spans preserve the source text."""
    if not annotations:
        return 1.0
    matches = sum(1 for annotation in annotations if text[annotation.start : annotation.end] == annotation.text)
    return matches / len(annotations)


def _candidate_accepted_separation(
    candidates: tuple[Track64AnnotationProposal, ...],
    accepted_annotations: tuple[Track64AnnotationProposal, ...],
) -> float:
    """Return whether candidate and accepted labels remain in separate lanes."""
    if not candidates and not accepted_annotations:
        return 1.0
    if not candidates or not accepted_annotations:
        return 0.0
    candidate_ok = all(annotation.status == "candidate" for annotation in candidates)
    accepted_ok = all(annotation.status == "accepted" for annotation in accepted_annotations)
    distinct_status = all(
        candidate.status != accepted_annotation.status
        for candidate in candidates
        for accepted_annotation in accepted_annotations
    )
    return 1.0 if candidate_ok and accepted_ok and distinct_status else 0.0


__all__ = [
    "DEFAULT_RETRIEVED_AT",
    "DEFAULT_SOURCE_URL",
    "SPACY_LLM_MODULE_NAME",
    "Track64AnnotationCase",
    "Track64AnnotationProposal",
    "Track64BackendOption",
    "Track64EvaluationResult",
    "Track64EvidenceReport",
    "build_track64_accepted_annotations",
    "build_track64_candidate_annotations",
    "build_track64_evidence_report",
    "default_track64_backend_options",
    "default_track64_cases",
    "render_track64_evidence_markdown",
    "run_track64_evaluation",
    "track64_candidate_to_extraction_record",
]
