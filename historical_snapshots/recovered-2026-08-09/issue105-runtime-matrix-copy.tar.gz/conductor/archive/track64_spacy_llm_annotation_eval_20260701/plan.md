# Track 64: spaCy-llm Annotation Pipeline Evaluation

**Status**: archived
**Dependencies**: Tracks 5, 10, 13, 20, 22, 55, 57, 62
**Parallelization Node**: LLM-Assisted spaCy Annotation

## Phase 1: Evaluation Surface

- [x] Task: Register Track 64 in `conductor/tracks.md` with the correct
  dependency and phase metadata. a364c83
- [x] Task: Add an optional `spacy-llm` evaluation helper with deterministic
  candidate and accepted annotation lanes. a364c83
- [x] Task: Add tests for span preservation, accepted-label separation, and
  Track 62 local inference compatibility. a364c83
- [x] Task: Add repo documentation comparing `spacy-llm`, DSPy, and custom
  prompt code. a364c83
- [x] Task: Conductor - User Manual Verification 'Phase 1: Evaluation Surface'
  (Protocol in workflow.md) a364c83

## Phase 2: Closeout

- [x] Task: Verify the local metadata, spec, plan, and index parse correctly.
  a364c83
- [x] Task: Verify the GitHub issue and project rows reflect the implemented
  track state. a364c83
- [x] Task: Run focused tests and `git diff --check`. a364c83
- [x] Task: Mark Track 64 archived in the tracks registry and commit the
  implementation. a364c83
- [x] Task: Conductor - User Manual Verification 'Phase 2: Closeout' (Protocol
  in workflow.md) a364c83
