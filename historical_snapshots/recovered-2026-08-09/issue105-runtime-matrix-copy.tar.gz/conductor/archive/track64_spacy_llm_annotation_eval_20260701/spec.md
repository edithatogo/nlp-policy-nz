# Track 64: spaCy-llm Annotation Pipeline Evaluation

Track 64 evaluates whether `spacy-llm` should be introduced as an optional
reviewable annotation layer inside the existing spaCy pipeline.

## Requirements

- Keep the canonical spaCy extraction path deterministic and available without
  `spacy-llm`.
- Evaluate one candidate annotation component with candidate/accepted label
  separation.
- Preserve annotation spans exactly in the evaluation surface.
- Support local inference backends where Track 62 already provides them.
- Record a decision comparing `spacy-llm` with DSPy-style custom prompt code.

## Acceptance Criteria

- [x] `spacy-llm` integration is optional and documented.
- [x] One candidate annotation component is prototyped or explicitly rejected
  with evidence.
- [x] Tests verify span preservation and candidate/accepted label separation.
- [x] Backend options include local inference where Track 62 supports it.
- [x] A decision record compares `spacy-llm` with DSPy/custom prompt code.

## Non-Goals

- Replacing the deterministic spaCy baseline.
- Making `spacy-llm` a required dependency.
- Removing the existing Track 62 local inference path.
