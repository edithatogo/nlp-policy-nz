# Track 64 Evidence

Track 64 evaluates `spacy-llm` as an optional annotation layer inside the
existing spaCy pipeline. The repo-side helper keeps candidate annotations and
accepted annotations in separate lanes, preserves exact spans, and documents
Track 62 local inference compatibility through optional backend metadata.

The decision boundary is to keep deterministic spaCy components canonical and
leave `spacy-llm` optional rather than required.

