# Track 64: spaCy-llm Annotation Pipeline Evaluation

## Links

- [Specification](./spec.md)
- [Implementation Plan](./plan.md)
- [Metadata](./metadata.json)

## Overview

Evaluate `spacy-llm` as an optional annotation layer for reviewable
LLM-assisted extraction while preserving deterministic spaCy baselines and
Track 62 local inference compatibility.

