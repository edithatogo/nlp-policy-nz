# Track 67: Rust-Native Pipeline Substitution Survey

**Dependencies**: Tracks 4, 6, 19, 23, 42, 55, 56, 59
**Parallelization Node**: Runtime Substitution Survey
**Status**: planned

## Overview

Track 67 surveys where Rust-backed or Rust-native libraries can replace or
consolidate Python-heavy surfaces in `nlp-policy-nz` without changing the
public API or the repo's Windows/GitHub Actions fallback behavior.

The goal is not to introduce a novelty stack. The goal is to reduce
duplication, keep the fastest stable path as the default, and document the
boundaries where an extra Rust-native dependency is justified.

## Scope

- Parsing, tokenization, and language identification.
- Rule matching and grammar checks.
- Validation, serialization, and data-frame operations.
- Search, vector storage, and table-backed analytics.
- IO and HTML or messy-document fallback surfaces.

## Requirements

- Reuse existing benchmark and decision evidence from Tracks 56, 59, 60, 63,
  64, 65, 66, and 68.
- Classify each candidate as `required`, `optional`, `deferred`, or
  `rejected`.
- Identify the top candidate surfaces by measured impact and maintenance
  simplicity.
- Document packaging risks for Windows, Linux, and GitHub Actions runners
  before any new runtime dependency is promoted.
- Preserve the existing Python API and the current Rust-backed defaults unless
  a survey result shows a clear reason to change.

## Acceptance Criteria

- [ ] Repo-wide Rust substitution matrix is produced.
- [ ] Profiling identifies the top candidate surfaces.
- [ ] At least one candidate is prototyped or explicitly rejected with
      evidence.
- [ ] Cross-platform packaging risks are documented before adoption.
- [ ] Tech-stack/dependency docs are updated with accepted, optional, and
      rejected candidates.

## Out of Scope

- Adding a production Rust rewrite for any hot path without survey evidence.
- Replacing the current Python fallback behavior on Windows or GitHub Actions.
- Promoting experimental analytics engines to default storage or retrieval
  backends without a track-specific benchmark decision.
