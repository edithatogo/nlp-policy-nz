# Track 67 Evidence

## Survey Summary

Track 67 consolidates the repo's existing Rust-backed and Rust-native
decisions into one survey instead of introducing a new default dependency
surface.

## Highest-Impact Surfaces

| Rank | Surface | Current Default | Survey Outcome | Evidence |
|---|---|---|---|---|
| 1 | Serialization and schema rendering | `msgspec` + `orjson` | Keep as required defaults | Tracks 56 and 55 already show the low-overhead JSON path is faster and simpler than adding a new serializer. |
| 2 | Tabular corpus operations | `polars` | Keep as required default | Track 59 shows the Polars core is the right Rust-backed layer for the hottest dataframe paths. |
| 3 | Vector retrieval and local search | `lancedb` | Keep as required default | Track 60 and the vector-store dependency decision keep LanceDB as the default local backend. |
| 4 | Grammar / rule matching | spaCy + rule-based components | Keep optional Rust-native matching only | Track 63 evaluated `nlprule` as an optional addition, not a default rewrite. |
| 5 | Parsing and tokenization | spaCy / fast tokenizers | Keep current defaults, consider point tools only | Track 56 and Track 65 already cover the span-preservation boundary and transformer-backed optionality. |

## Explicit Rejections or Deferrals

- `RocksDB` is rejected for this repo's current abstractions because it does
  not replace Parquet artifacts, LanceDB vector search, or SQLite-style
  manifest catalogs.
- `DuckDB` with VSS remains an experimental analytics candidate, not a default
  vector store.
- `selectolax` is optional for HTML-heavy input paths, but it is not a blanket
  replacement for the current document parsing stack.
- Custom Rust/PyO3/maturin extensions remain deferred until a benchmark shows
  a hotspot that the existing Rust-backed libraries cannot solve.

## Packaging Risks

- Windows wheel support for any new compiled dependency must be verified in CI.
- Linux GitHub Actions runners must keep a Python fallback path so the survey
  stays executable without optional extras.
- Optional dependencies should remain behind extras or feature flags so the
  default install surface stays manageable.
- Any new Rust-native crate should have a narrow FFI boundary and a clear
  rollback story.

## Decision

The repo already has the right Rust-backed defaults for the hottest surfaces.
Track 67 does not justify a broad default dependency swap. It documents where
extra Rust-native tools are useful, where they should stay optional, and where
they should stay out of the default stack.
