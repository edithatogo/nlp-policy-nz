# Track 67: Rust-Native Pipeline Substitution Survey

- [Specification](./spec.md)
- [Implementation Plan](./plan.md)
- [Metadata](./metadata.json)
- [Evidence](./evidence.md)
