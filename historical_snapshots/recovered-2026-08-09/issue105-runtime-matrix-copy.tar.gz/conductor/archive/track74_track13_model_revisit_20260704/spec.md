# Track 74: Revisit Track 13 legal model choices after NZ legislation fine-tuning

## Overview

Track 74 is the planned follow-up for the Track 13 model-selection decision.
It keeps the revisit open until a held-out NZ legal evaluation set or a
NZ-legislation/Hansard fine-tuned model exists, then compares the local legal
encoder and adjudication candidates against the current baseline choices.

## Requirements

- Keep the follow-up open until the trigger artifact exists.
- Treat `isaacus/emubert` as the preferred Australasian encoder baseline
  candidate for comparison against Legal-BERT.
- Treat `Equall/Saul-7B-Instruct-v1` and `isaacus/open-australian-legal-llm`
  as silver-label adjudication candidates only.
- Keep gold-label evidence separate from silver-label and model-generated
  outputs.
- Leave production behavior unchanged until the follow-up has evidence.

## Acceptance Criteria

- The follow-up track remains open while the trigger artifact is absent.
- A held-out NZ legal/Hansard evaluation report, dataset hash, and model IDs
  are recorded before any recommendation is promoted.
- The Track 13 evidence trail captures the selected classifier and
  adjudication-provider roles.
- Silver labels are never represented as human-gold labels.

## Out of Scope

- Training or fine-tuning the replacement model.
- Changing production dependency defaults.
- Replacing Legal-BERT or EmuBert without held-out evidence.
