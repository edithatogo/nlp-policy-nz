# Track 74: Revisit Track 13 legal model choices after NZ legislation fine-tuning

**Status**: planned
**Dependencies**: Tracks 13, 20, 22, 53
**Parallelization Node**: Model Revisit and Evaluation

## Phase 1: Follow-up Setup

- [x] Task: Register Track 74 as the local follow-up for GitHub issue #2.
- [x] Task: Add conductor metadata and hidden track markers to issue #2.
- [x] Task: Record the trigger artifact, candidate model set, and separation
  rules for gold versus silver evidence.
- [x] Task: Conductor - User Manual Verification 'Phase 1: Follow-up Setup' (Protocol in workflow.md)

## Phase 2: Triggered Evaluation Gate

- [x] Task: Wait for a held-out NZ legal evaluation set or a
  NZ-legislation/Hansard fine-tuned model before changing any recommendation.
- [x] Task: Compare `isaacus/emubert` against Legal-BERT and the silver-label
  adjudication candidates on the Track 13 follow-up criteria.
- [x] Task: Record the decision note and evidence trail without promoting
  silver labels to human-gold labels.
- [x] Task: Conductor - User Manual Verification 'Phase 2: Triggered Evaluation Gate' (Protocol in workflow.md)
