# Track 63: nlprule Grammar and Rule Matching Evaluation

Track 63 evaluates whether nlprule-style grammar and rule matching should be
introduced as an optional rule engine for legal drafting quality checks and
structured extraction cues.
This archived record preserves the evaluation outcome and decision trail.

## Requirements

- Preserve spaCy as the maintained and default tokenization and matching path.
- Evaluate nlprule-style grammar matching without adding a required dependency.
- Keep Te Reo Māori token preservation intact, including macronized forms.
- Map rule output into the repo's existing extraction and quality schemas.
- Record a clear decision on whether nlprule stays optional, experimental, or
  rejected as a required dependency.

## Acceptance Criteria

- [x] Library viability is assessed before dependency changes.
- [x] A prototype or documented rejection compares nlprule with spaCy rules.
- [x] Māori token preservation and legal span alignment tests pass.
- [x] Rule outputs are mapped to existing quality/extraction schemas.
- [x] A decision record defines adoption scope or rejection rationale.

## Non-Goals

- Replacing spaCy pipeline components.
- Making nlprule a required runtime dependency.
- Changing the canonical extraction families or schema definitions.
