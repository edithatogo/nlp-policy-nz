# Track 65 Evidence

Track 65 evaluates `spacy-transformers` as an optional transformer-backed
upgrade path for spaCy components that benefit from contextual embeddings.

## Evidence Notes

- Deterministic spaCy fallback remains available.
- Token/span alignment is evaluated on legal and Māori-sensitive fixtures.
- Transformer-backed component lanes are compared with baseline lanes.
- The decision record stays explicit about where the upgrade is adopted or
  deferred.
