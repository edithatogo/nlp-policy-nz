# Track 65: spacy-transformers Pipeline Upgrade Evaluation

**Status**: archived
**Dependencies**: Tracks 3, 5, 10, 12, 13, 20, 23
**Parallelization Node**: Transformer-Backed spaCy Components

## Phase 1: Evaluation Surface

- [x] Task: Register Track 65 in `conductor/tracks.md` with the correct
      dependency and phase metadata. a43fe35
- [x] Task: Add an optional `spacy-transformers` evaluation helper with
      deterministic candidate and baseline component lanes. a43fe35
- [x] Task: Add tests for token/span alignment, Māori guard compatibility, and
      fallback behaviour. a43fe35
- [x] Task: Add repo documentation comparing `spacy-transformers` to the
      deterministic spaCy baseline. a43fe35
- [x] Task: Conductor - User Manual Verification 'Phase 1: Evaluation Surface'
      (Protocol in workflow.md) a43fe35

## Phase 2: Closeout

- [x] Task: Verify the local metadata, spec, plan, and index parse correctly.
      a43fe35
- [x] Task: Verify the GitHub issue and project rows reflect the implemented
      track state. a43fe35
- [x] Task: Run focused tests and `git diff --check`. a43fe35
- [x] Task: Mark Track 65 archived in the tracks registry and commit the
      implementation. a43fe35
- [x] Task: Conductor - User Manual Verification 'Phase 2: Closeout' (Protocol
      in workflow.md) a43fe35
