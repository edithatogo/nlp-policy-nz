# Track 65: spacy-transformers Pipeline Upgrade Evaluation

## Links

- [Specification](./spec.md)
- [Implementation Plan](./plan.md)
- [Metadata](./metadata.json)
- [Evidence](./evidence.md)

## Overview

Evaluate `spacy-transformers` as an optional transformer-backed spaCy upgrade
path for legal NLP components that benefit from shared contextual embeddings,
while preserving deterministic fallback behaviour and Māori token/span
compatibility.
