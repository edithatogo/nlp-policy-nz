# Track 65: spacy-transformers Pipeline Upgrade Evaluation

Track 65 evaluates whether `spacy-transformers` should be used for optional
transformer-backed spaCy components in the legal NLP pipeline.

## Requirements

- Keep the canonical spaCy baseline available without `spacy-transformers`.
- Evaluate candidate transformer-backed spaCy components against baseline
  token/span alignment.
- Preserve Māori token handling and token-span compatibility.
- Record where the upgrade is useful and where deterministic spaCy remains the
  preferred lane.
- Document fallback behaviour when the optional dependency is unavailable.

## Acceptance Criteria

- [x] Candidate components and baseline metrics are documented.
- [x] At least one optional `spacy-transformers` config is prototyped or
      rejected.
- [x] Tests cover token/span alignment, Māori guard compatibility, and
      fallback.
- [x] Benchmarks report latency, memory, and quality deltas.
- [x] A decision record states where `spacy-transformers` is adopted or
      deferred.

## Non-Goals

- Replacing deterministic spaCy tokenisation as the canonical baseline.
- Making `spacy-transformers` a required dependency.
- Removing the existing non-transformer fallback path.
