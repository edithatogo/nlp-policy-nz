# Track 66: marimo Reactive Prototyping and Evaluation Workbench

## Links

- [Specification](./spec.md)
- [Implementation Plan](./plan.md)
- [Metadata](./metadata.json)
- [Evidence](./evidence.md)

## Overview

Evaluate marimo as a reactive, reproducible workbench for corpus profiling,
model evaluation, and legal NLP dashboards.
