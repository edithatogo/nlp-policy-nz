# Track 66: marimo Reactive Prototyping and Evaluation Workbench

Track 66 evaluates whether marimo should be used as a reactive, versionable
workbench for corpus profiling and analysis dashboards.

## Requirements

- Keep the deterministic repo-side analysis helpers usable without marimo.
- Prototype a marimo app surface that reads committed fixtures or documented
  artifacts.
- Preserve the analysis boundary so marimo remains optional for CI and GitHub
  Actions.
- Document where marimo helps and where the repo should stay as plain Python
  modules or scripts.
- Keep the prototype reviewable and reproducible from committed inputs.

## Acceptance Criteria

- [x] One marimo app prototype is implemented or explicitly deferred with
      evidence.
- [x] The prototype reads committed fixtures or documented artifacts.
- [x] Tests/static checks verify importability and artifact assumptions.
- [x] Docs explain marimo usage, limitations, and replacement boundaries.
- [x] A decision record states whether marimo is adopted for future analysis
      workflows.

## Non-Goals

- Replacing plain Python modules with marimo everywhere.
- Making marimo a required dependency for the core pipeline.
- Moving analysis logic out of reusable repo modules.
