"""Conductor closeout tests for Track 18."""

from __future__ import annotations

import json
from pathlib import Path

TRACK18 = Path("conductor/tracks/archive/track18_voting_amendments_20260613")


def test_track18_conductor_track_is_archived_and_complete() -> None:
    """Track 18 conductor artifacts should reflect reviewed archive status."""
    metadata = json.loads(TRACK18.joinpath("metadata.json").read_text(encoding="utf-8"))
    registry = Path("conductor/tracks.md").read_text(encoding="utf-8")

    assert metadata["track_id"] == "track18_voting_amendments_20260613"
    assert metadata["status"] == "complete"
    assert "## [x] Track 18: Voting Record Analysis & Amendment Tracking (archived)" in registry
    assert "conductor/tracks/archive/track18_voting_amendments_20260613" in registry

    for required_file in ("index.md", "metadata.json", "plan.md", "spec.md", "evidence.md"):
        assert TRACK18.joinpath(required_file).is_file()


def test_track18_evidence_records_validation_and_boundary() -> None:
    """Track 18 evidence should record focused validation and full-suite boundary."""
    evidence = TRACK18.joinpath("evidence.md").read_text(encoding="utf-8")

    assert "tests/test_voting.py" in evidence
    assert "tests/test_amendments.py" in evidence
    assert "15 tests" in evidence
    assert "93% total coverage" in evidence
    assert "No space left on device" in evidence
