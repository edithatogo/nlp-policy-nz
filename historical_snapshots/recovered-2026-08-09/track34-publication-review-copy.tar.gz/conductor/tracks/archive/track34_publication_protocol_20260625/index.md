# Track 34: Standards-Based Publication Protocol

- [Specification](./spec.md)
- [Implementation Plan](./plan.md)
- [Metadata](./metadata.json)
- [Evidence](./evidence.md)

## Implementation

- `src/nlp_policy_nz/publication/protocol.py`
- `src/nlp_policy_nz/cli/main.py` (`publication-protocol`)
- `tests/test_track34_publication_protocol.py`
- `tests/test_track34_conductor.py`

## Outputs

- `data/publication/publication_protocol_manifest.json`
- `data/publication/publication_protocol_claims.json`
- `data/publication/publication_protocol_inventory.json`
- `data/publication/publication_protocol_overclaim_review.json`
- `docs/publication_protocol.md`

## Boundary

The protocol is evidence-mapped and does not convert blockers, planned work, or external gates into completed claims.
