# Track 34: Standards-Based Publication Protocol

**Dependencies**: Tracks 24-33
**Parallelization Node**: Publication Protocol
**Status**: Complete

## Implementation Plan

| # | Task | Status | Owner |
|---|------|--------|-------|
| 1 | Inventory all achieved repo evidence: completed track evidence files, test suites, CI workflows, schema validators, documentation | [x] | conductor_orchestrator |
| 2 | Inventory planned-but-blocked work with blocker references from the blocker register | [x] | conductor_orchestrator |
| 3 | Map protocol claims to evidence paths: for each protocol claim (e.g., "AKN v3 compliance"), list the specific files/tests that substantiate it | [x] | conductor_orchestrator |
| 4 | Draft protocol section 1: Repository overview, pipeline architecture, and reproducibility instructions | [x] | conductor_orchestrator |
| 5 | Draft protocol section 2: Standards compliance matrix with coverage status per standard | [x] | conductor_orchestrator |
| 6 | Draft protocol section 3: Ontology mapping and reasoning capabilities | [x] | conductor_orchestrator |
| 7 | Draft protocol section 4: Corpus statistics and analysis methodology | [x] | conductor_orchestrator |
| 8 | Review for: standards claims accuracy, overclaim risk (label external-gate evidence correctly), reproducibility (can a fresh checkout reproduce results?), completeness against FAIR principles | [x] | conductor_orchestrator |

## Evidence Boundary

Repo-side scaffolds, manifests, fixtures, and diagrams can satisfy planning and deterministic evidence tasks. Full-corpus, live publication, authenticated API, or external-source tasks must remain blockers until the corresponding data or access is actually available and recorded.

## Implementation Note - 2026-07-01

Track 34 is implemented as a deterministic, evidence-mapped publication protocol:

- `src/nlp_policy_nz/publication/protocol.py` builds a publication protocol bundle with claim evidence mapping, artifact inventory, reproducibility commands, and overclaim-risk review.
- `data/publication/` contains checked-in JSON artifacts for the protocol manifest, claims, inventory, and overclaim review.
- `docs/publication_protocol.md` records the human-readable protocol with standards, methods, ontology, analysis, artifact, reproducibility, and limitation sections.
- `nlp-policy-nz publication-protocol` exposes protocol generation for CI and local reproduction.
- Full-corpus, live publication, authenticated API, external-source, and figure-production claims remain gated by explicit blocker, external-gate, or planned statuses.

## Review Fixes - 2026-07-01

- [x] Reformatted the publication protocol generator to make evidence-backed claim rows and overclaim checks easier to audit without changing generated protocol content.
