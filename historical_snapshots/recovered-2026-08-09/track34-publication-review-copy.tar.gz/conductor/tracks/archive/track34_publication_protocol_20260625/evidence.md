# Track 34 Evidence: Standards-Based Publication Protocol

## Repo-Side Implementation

- Added `src/nlp_policy_nz/publication/protocol.py` for deterministic Track 34 publication protocol generation.
- Added `nlp-policy-nz publication-protocol` to export protocol artifacts from checked-in repo evidence.
- Added checked-in artifacts under `data/publication/`: `publication_protocol_manifest.json`, `publication_protocol_claims.json`, `publication_protocol_inventory.json`, and `publication_protocol_overclaim_review.json`.
- Added `docs/publication_protocol.md` as the standards-based publication protocol.
- Added `tests/test_track34_publication_protocol.py` and `tests/test_track34_conductor.py`.

## Boundaries

- Protocol claims are categorized as repo evidence, external gate, planned, or blocker.
- The protocol does not claim full-corpus statistics or full graph/vector coverage without supplied full-corpus inputs.
- Live Zenodo, Hugging Face, authenticated API, or external-source publication evidence remains an external gate.
- Figure and notebook production remains planned for Track 35.

## Closeout Validation

- `pixi run python -m pytest -q tests\test_track34_publication_protocol.py tests\test_track34_conductor.py tests\test_cli.py` passed.
- `pixi run python -m pytest -q tests\test_track31_nz_ontologies.py tests\test_track32_corpus_statistics.py tests\test_track33_graph_vector_network.py tests\test_track34_publication_protocol.py tests\test_track34_conductor.py tests\test_cli.py` passed.
- `pixi run python -m ruff check --no-cache src\nlp_policy_nz\publication\protocol.py src\nlp_policy_nz\publication\__init__.py src\nlp_policy_nz\__init__.py src\nlp_policy_nz\cli\main.py tests\test_track34_publication_protocol.py tests\test_track34_conductor.py tests\test_cli.py` passed.
- Fresh `write_publication_protocol_artifacts()` output matches checked-in Track 34 artifacts.
- `git diff --check` passed.
