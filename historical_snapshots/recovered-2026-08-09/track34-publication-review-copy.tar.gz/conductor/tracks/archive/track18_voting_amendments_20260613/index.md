# Track 18: Voting Record Analysis and Amendment Tracking

## Key files

- `src/nlp_policy_nz/parliament/voting.py`
- `src/nlp_policy_nz/parliament/amendments.py`
- `tests/test_voting.py`
- `tests/test_amendments.py`
- `conductor/tracks/track18_voting_amendments_20260613/spec.md`
- `conductor/tracks/track18_voting_amendments_20260613/plan.md`
- `conductor/tracks/track18_voting_amendments_20260613/evidence.md`

## Implementation decision

Track 18 remains focused on deterministic parsing, structural diffs, lifecycle graph evidence, and pipeline/CLI enrichment. Full production corpus validation is a data and environment gate rather than a blocker for the repo-side implementation.
