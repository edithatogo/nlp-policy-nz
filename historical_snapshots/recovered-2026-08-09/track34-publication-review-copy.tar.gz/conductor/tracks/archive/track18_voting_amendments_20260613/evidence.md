# Track 18 Evidence

## Implemented surface

- `src/nlp_policy_nz/parliament/voting.py`
- `src/nlp_policy_nz/parliament/amendments.py`
- `src/nlp_policy_nz/parliament/__init__.py`
- `src/nlp_policy_nz/storage/serialization.py`
- `src/nlp_policy_nz/pipeline_api.py`
- `src/nlp_policy_nz/api/server.py`
- `src/nlp_policy_nz/cli/main.py`
- `tests/test_voting.py`
- `tests/test_amendments.py`

## Review summary

The completed implementation covers Hansard division parsing, party/personal vote handling, amendment parsing, structural bill-version diffs, amendment lifecycle graph construction, `PipelineRecord` enrichment, dataframe/Parquet retention, API response enrichment, and CLI commands for `voting-summary` and `amendment-history`.

## Validation

- `python -m pytest tests\test_voting.py tests\test_amendments.py -p no:cacheprovider -q` passed with 15 tests.
- `python -m ruff check --no-cache src\nlp_policy_nz\parliament\amendments.py tests\test_amendments.py tests\test_voting.py src\nlp_policy_nz\parliament\__init__.py` passed.
- `python -m coverage report --data-file=.tmp\coverage\track18b.coverage --include=src\nlp_policy_nz\parliament\* -m` reported 93% total coverage across `parliament`.

## Blocker boundary

Broad full-suite validation was not repeated during the original closeout because the local workstation hit a hard `No space left on device` condition while creating test artifacts. Focused Track 18 tests and lint passed, and generated test output was cleaned up.
