# Mojo Migration Roadmap

## Purpose

This roadmap records a future migration path for incrementally introducing Mojo into `nlp-policy-nz` without destabilizing the current Python, Rust-backed Python, Pixi, and GitHub Actions workflows.

The goal is not a wholesale rewrite. The goal is to identify hot, deterministic, low-dependency kernels that could benefit from Mojo while keeping the public Python API, Parquet artifacts, conductor tracks, and downstream repository contracts stable.

## Current position

`nlp-policy-nz` is a Python-first research and production pipeline with performance-sensitive pieces already delegated to Rust-backed libraries:

- `msgspec` and `orjson` for schema and JSON performance.
- Polars, Arrow, and Parquet for tabular data flow.
- LanceDB for local vector storage.
- Hugging Face fast tokenizers and spaCy/Thinc for NLP runtime behavior.
- Optional Rust/PyO3/maturin work remains available for extension modules.

Mojo is a future candidate for focused compute kernels, but it must earn adoption through benchmarks, packaging evidence, CI support, and compatibility with this repo's local-first Windows development workflow.

## External state to track

As of July 1, 2026:

- The PyPI `mojo` package is published by Modular Inc and includes the compiler, standard library, LSP, debugger, and related tooling.
- PyPI metadata says Mojo is not available for Windows.
- Current wheels are for Linux and macOS targets, which means this repo cannot make Mojo required for the default Windows workstation workflow yet.
- Modular's public platform repository includes MAX and Mojo components, with Mojo examples, standard-library material, and MAX kernels.

Source references:

- `https://pypi.org/project/mojo/`
- `https://github.com/modular/modular`
- `https://mojolang.org/docs/manual/`

## Migration principles

1. Keep Python as the stable public API.
2. Keep all existing Python tests as the behavioral oracle.
3. Only migrate code after profiling proves a material bottleneck.
4. Prefer replacing private kernels, not public data models.
5. Keep Mojo optional until Windows support, GitHub Actions support, and packaging are reliable.
6. Maintain byte-for-byte or schema-level parity for generated JSON, CSV, Parquet, RDF, and Markdown artifacts.
7. Do not introduce Mojo into legal reasoning, ontology, or publication paths where correctness explainability is more important than throughput.
8. Treat Mojo, Rust, Polars plugins, msgspec, and vector-store improvements as competing acceleration options, not automatic complements.

## Runtime decision matrix

Every proposed Mojo migration must be evaluated against the current runtime and at least two realistic alternatives. Mojo should be chosen only when it is the best fit for the bottleneck, not because it is the newest option.

| Option | Best fit | Avoid when |
|---|---|---|
| Python with Rust-backed libraries | Default pipeline behavior, schema handling, orchestration, testability | Profiling shows tight CPU loops dominate runtime |
| Polars expressions/plugins | Columnar transforms, Parquet/Arrow-heavy operations, dataframe-native work | The logic is not naturally columnar or needs complex Python object behavior |
| Rust/PyO3/maturin | Stable compiled kernels, Windows support, packaging maturity | The implementation cost exceeds the measured runtime gain |
| Mojo | Isolated numeric or text kernels where Python interop is clean and benchmark wins are clear | Windows, packaging, CI, or fallback behavior is unresolved |
| DuckDB extensions | SQL-like analytical workloads and embedded reporting joins | The workload is not relational or extension maturity blocks reproducibility |
| LanceDB-native paths | Vector indexing, retrieval, and Arrow-native vector workflows | The bottleneck is pre-index extraction or post-query interpretation |
| vLLM/MAX/Transformers runtime changes | Model inference throughput and batching | The target is deterministic extraction, schema projection, or publication assembly |

Decision notes should record why rejected alternatives were not chosen. A short table in the relevant future conductor track is enough.

## Profiling and benchmark governance

Mojo work must start from measured bottlenecks, not intuition.

Required evidence before opening an implementation track:

- A profiler result from `scalene`, `memray`, `py-spy`, `austin`, or an equivalent benchmark harness.
- A stable benchmark corpus with input hashes and expected output hashes.
- Baseline timings for current Python/Rust-backed behavior.
- A comparison against at least one non-Mojo acceleration path.
- A stated minimum improvement threshold before integration work begins.

Recommended benchmark corpus slices:

| Slice | Purpose | Required artifacts |
|---|---|---|
| Legislation extraction sample | Text normalization and provision/citation matching | Input hash, extracted spans, offset parity report |
| Large manifest projection | JSON/schema serialization and artifact generation | JSON schema validation, ordering parity, wall time |
| Vector retrieval fixture | Embedding/vector math and query post-processing | Recall fixture, tolerance report, timing |
| Publication review fixture | Rubric aggregation and report generation | Review JSON, Markdown output, blocker-label parity |

Benchmark artifacts should record OS, CPU/GPU, memory, Python version, Mojo version, dependency lockfile hash, input size, and command line.

## Interop, packaging, and CI strategy

Mojo should be introduced through optional feature detection only.

Preferred integration shape:

1. Python remains the canonical entrypoint.
2. Mojo kernels are private implementation details.
3. Import or runtime detection chooses Mojo only when available.
4. Python fallback is always exercised in default tests.
5. Optional CI validates Mojo on a supported Linux or macOS runner when available.
6. Windows and default GitHub Actions jobs must not require Mojo.

Packaging rules:

- Do not add Mojo to required dependencies until Windows and CI support are proven.
- Do not publish artifacts whose behavior depends silently on Mojo availability.
- If Mojo acceleration is used, include that fact in benchmark and release metadata.
- Keep lockfile and environment changes scoped to an optional profile.

## Safety and correctness boundaries

Mojo is suitable for deterministic performance kernels. It is not a substitute for legal or policy judgment.

Do not migrate these areas without a separate correctness review:

- Legal reasoning or interpretation.
- Ontology design, policy classification, and semantic entailment.
- Citation validity judgments.
- Human-facing explanation text.
- Publication wording or review conclusions.

Any accelerated path that touches legal/NLP outputs must preserve traceability back to source text, offsets, labels, hashes, and review evidence.

## Exit and rollback criteria

Every Mojo experiment must have removal criteria before it starts.

Remove or freeze a Mojo experiment when any of these occur:

- It fails to beat the current implementation by the agreed threshold.
- Rust/PyO3, Polars, DuckDB, LanceDB, or existing Python libraries provide a simpler equivalent path.
- It blocks default GitHub Actions.
- It cannot provide deterministic Python fallback behavior.
- It complicates packaging or local Windows development beyond the measured value.
- It changes artifact schemas, ordering, offsets, or labels without an approved migration plan.

Rollback should be simple: disable feature detection, keep Python fallback as canonical, and remove optional CI/profile wiring in a single track.

## Roadmap lifecycle

Mojo support and packaging are moving targets, so this roadmap must be refreshed before it drives implementation work.

Review cadence:

- Re-check external state at least quarterly while Mojo remains unsupported on the default Windows workstation path.
- Re-check immediately before opening any Mojo conductor track.
- Update the `External state to track` section with the date, version, supported platforms, install method, and source links.
- Keep stale assumptions visible until they are replaced with new evidence.

Required review inputs:

- PyPI/package availability and supported wheel targets.
- Official documentation for Python interop, packaging, testing, and supported platforms.
- GitHub Actions runner support.
- License and redistribution terms.
- Local developer install path for Windows, WSL, Linux, and macOS.
- Compatibility with `pixi`, `uv`, lockfiles, and existing release packaging.

## Risk register

| Risk | Impact | Mitigation |
|---|---|---|
| Windows support remains unavailable | Default local workflow cannot use Mojo | Keep Mojo optional and use WSL/Linux-only experiments at most |
| Packaging model changes | CI or release artifacts become brittle | Keep optional profiles isolated from default dependencies |
| Python interop overhead erases gains | Added complexity without measurable benefit | Benchmark end-to-end calls, not just kernel microbenchmarks |
| Legal output drift | Faster code changes offsets, labels, or traceability | Require artifact parity, source hashes, and review fixtures |
| Duplicate acceleration stacks accumulate | Repo becomes harder to maintain | Use the runtime decision matrix before each track |
| Experimental dependency slows CI | Default validation becomes less reliable | Keep Mojo jobs non-blocking until production gates pass |
| Licensing uncertainty | Distribution or deployment risk | Re-check license terms before experiments and before integration |

## Adoption scoring rubric

Before promoting any Mojo proposal into an implementation track, score it from 0 to 2 on each dimension.

| Dimension | 0 | 1 | 2 |
|---|---|---|---|
| Bottleneck evidence | No measured bottleneck | Local benchmark only | Reproducible profiler and benchmark evidence |
| Runtime benefit | No clear gain | Narrow microbenchmark gain | End-to-end workflow gain |
| Platform support | Unsupported on required paths | Optional Linux/macOS only | Compatible with required local and CI paths |
| Packaging cost | Requires default dependency churn | Optional profile with friction | Clean optional install and lockfile story |
| Correctness parity | Untested | Partial parity checks | Full artifact and behavioral parity |
| Maintainability | New specialist surface area | Small isolated kernel | Clear owner, tests, fallback, and removal path |

Promotion threshold:

- Score at least 9 out of 12.
- Score 2 for correctness parity.
- Score at least 1 for platform support.
- Document any dimension scoring below 2 in the future conductor track.

## Track and GitHub issue promotion policy

This roadmap should not create active implementation work by itself. Promote work only when a concrete decision point exists.

Promotion rules:

- Create a conductor track for each future Mojo stage only when the previous stage's exit criteria are satisfied.
- Mirror promoted tracks into GitHub issues if the repo's project board is active.
- Label GitHub issues with `roadmap`, `runtime`, `performance`, and `mojo` where available.
- Include acceptance criteria copied from this roadmap rather than free-form implementation wishes.
- Close or archive a promoted track when evidence says Mojo is not the right tool for that stage.

Suggested issue fields:

| Field | Value |
|---|---|
| Status | Backlog until readiness gates are met |
| Priority | Low unless a measured bottleneck blocks release work |
| Area | Runtime / Performance |
| Risk | Experimental dependency |
| Evidence required | Profiling, benchmark, parity, CI, packaging, license |

## Candidate migration surfaces

### Tier 1: Good first candidates

These are deterministic, narrow, testable, and likely to benefit from compiled execution.

| Candidate | Current owner | Why it fits | Required parity |
|---|---|---|---|
| Hot token normalization loops | `src/nlp_policy_nz/*` text helpers | CPU-bound string scanning can be isolated | Same Unicode NFC/macron behavior |
| Citation and provision span matching kernels | citation/extraction helpers | Repetitive pattern matching over large text | Same offsets, labels, and source trace |
| Extraction manifest projection | `src/nlp_policy_nz/extraction/` | Track 56 already benchmarks serialization paths | Same JSON schema and ordering |
| Lightweight vector math kernels | graph/vector analysis helpers | Deterministic numeric kernels can be benchmarked | Same tolerances and blocker labels |
| Batch scoring or rubric aggregation | publication/review artifacts | Pure numeric aggregation; low risk | Same review JSON schema |

### Tier 2: Later candidates

These need more packaging or integration evidence first.

| Candidate | Reason to defer |
|---|---|
| Full parser rewrites | spaCy/BeautifulSoup/XML behavior is semantically subtle |
| Polars plugin replacements | Rust plugins may remain simpler and better integrated |
| LanceDB internals | External dependency, not repo-owned |
| Hugging Face model execution | vLLM/MAX/Transformers integration should be evaluated separately |
| API server paths | I/O-bound; performance likely dominated by model/data access |

### Out of scope for now

- Rewriting the full package in Mojo.
- Making Mojo a required dependency in `pyproject.toml`.
- Replacing Python conductor workflows.
- Replacing stable Rust/PyO3 candidates without benchmark evidence.
- Depending on live MAX/Mojo services for default tests.

## Staged roadmap

### Stage 0: Monitoring and readiness

Objective: keep Mojo visible without touching runtime behavior.

Tasks:

- Add a quarterly check for Mojo Windows support, PyPI wheels, licensing, and GitHub Actions availability.
- Record supported OS, install command, version, and license in this roadmap.
- Keep all findings evidence-linked and date-stamped.
- Do not add Mojo to default dependencies.

Exit criteria:

- A maintainer can install Mojo in a non-default local or CI environment.
- License terms are compatible with repo distribution goals.
- The default Windows workflow remains unaffected.

### Stage 1: Experimental sandbox

Objective: add isolated examples without production coupling.

Tasks:

- Create `experiments/mojo/` only after a supported local or CI runner exists.
- Add a tiny deterministic kernel with Python reference output.
- Add a non-blocking CI job on a supported OS.
- Generate benchmark artifacts under `artifacts/mojo/`.

Exit criteria:

- Python and Mojo outputs match.
- CI can skip cleanly when Mojo is unavailable.
- Benchmark artifact records hardware, OS, Mojo version, input size, and result hash.

### Stage 2: Benchmark-backed prototype

Objective: compare Mojo against Python, msgspec/orjson, Polars, Rust/PyO3, and existing vector/runtime paths.

Tasks:

- Extend Track 56-style benchmark harnesses with optional Mojo candidates.
- Compare wall time, memory, artifact parity, install cost, and CI friction.
- Record whether Mojo beats existing Rust-backed Python options by a meaningful margin.

Exit criteria:

- At least one kernel shows a clear speedup over current implementation and a lower maintenance cost than a Rust/PyO3 alternative.
- Parity tests pass on all affected artifacts.
- The result is documented in `docs/extraction-runtime.md` or a successor decision note.

### Stage 3: Optional package integration

Objective: expose one optional Mojo-accelerated path behind feature detection.

Tasks:

- Add optional install guidance, not a default dependency.
- Add runtime feature detection and deterministic fallback to Python.
- Keep the public API unchanged.
- Ensure GitHub Actions still passes without Mojo.

Exit criteria:

- Users without Mojo get identical behavior.
- Users with Mojo get measurable speedup.
- Release artifacts clearly state whether Mojo acceleration was used.

### Stage 4: Production candidate

Objective: decide whether Mojo becomes part of a production runtime profile.

Tasks:

- Add a dedicated conductor track only after Stages 0-3 produce evidence.
- Add OS matrix support and packaging checks.
- Decide between Mojo, Rust/PyO3, Polars plugins, or staying Python/Rust-backed.
- Update `pyproject.toml`, `pixi.toml`, docs, and CI only if Mojo becomes required or formally optional.

Exit criteria:

- Mojo has stable install support on the repo's required operating systems, or the repo formally supports a non-Windows acceleration profile.
- Maintenance cost is acceptable.
- The accelerated path has benchmark, parity, and rollback evidence.

## Proposed future conductor tracks

These are roadmap items, not active tracks:

1. `track_mojo_readiness_audit_<date>`: verify OS support, licensing, packaging, GitHub Actions support, and candidate kernel shortlist.
2. `track_mojo_experiment_sandbox_<date>`: add optional `experiments/mojo/` kernels and non-blocking CI.
3. `track_mojo_runtime_benchmark_<date>`: extend Track 56 benchmarks with Mojo candidates and compare against Rust/PyO3 and Polars plugins.
4. `track_mojo_optional_acceleration_<date>`: integrate one proven kernel behind optional feature detection and Python fallback.

## Decision gates

Mojo should not move from roadmap to implementation until all of these are true:

- Supported runner exists for local development or CI.
- Licensing and redistribution are acceptable for this repo.
- A target kernel is isolated and deterministic.
- Python fallback remains the canonical behavior.
- Benchmarks show a meaningful win over existing Rust-backed Python approaches.
- Artifact parity is proven by tests.
- The dependency does not block default GitHub Actions.

## Current recommendation

Keep Mojo on the future roadmap, but continue the near-term implementation sequence with Tracks 38-52. The immediate modernization path should still prioritize reproducible containers, dependency/security automation, data-quality monitoring, release engineering, production hardening, and API security before adopting a new language runtime.
