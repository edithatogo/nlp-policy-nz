# Standards-Based Publication Protocol

Track 34 defines a publication-ready protocol for the current repo-side evidence. It does not claim full-corpus, live publication, authenticated API, or external-source completion unless the cited evidence exists.

## Scope and evidence boundary

This protocol maps publication claims to checked-in repo evidence, external gates, planned work, or blockers. It does not claim full-corpus, live publication, authenticated API, or external-source completion unless those artifacts are explicitly present.

## Repository overview and methods

- Pipeline architecture is grounded in `README.md`, `conductor/product.md`, and the CLI entrypoints in `src/nlp_policy_nz/cli/main.py`.
- Ontology and standards claims are grounded in checked-in manifests under `data/ontologies/`.
- Analysis claims are grounded in deterministic Track 32 and Track 33 artifacts under `data/statistics/` and `data/analysis/`.

## Standards compliance matrix

| Claim | Status | Evidence |
| --- | --- | --- |
| corpus-statistics | repo_evidence | `data/statistics/corpus_statistics_manifest.json`, `data/statistics/corpus_statistics_per_corpus.csv`, `docs/corpus_statistics.md` |
| figure-production | planned | `conductor/tracks/track35_analysis_artifact_execution_20260625/spec.md` |
| full-corpus-statistics | blocker | `data/statistics/corpus_statistics_blockers.json` |
| full-graph-vector | blocker | `data/analysis/graph_vector_blockers.json` |
| graph-vector-analysis | repo_evidence | `data/analysis/graph_vector_manifest.json`, `data/analysis/graph_vector_graph_metrics.json`, `docs/graph_vector_network_analysis.md` |
| live-zenodo-hf-publication | external_gate | `README.md`, `.github/workflows/release.yml`, `src/nlp_policy_nz/integrations/release.py` |
| mapping-graph | repo_evidence | `data/ontologies/ontology_mappings.json`, `data/ontologies/inferred_mapping_candidates.json`, `docs/ontology_mapping.md` |
| ontology-strategy | repo_evidence | `data/ontologies/nz_ontology_candidates.json`, `data/ontologies/nz_controlled_vocabularies.json`, `docs/nz_ontologies.md` |
| pipeline-architecture | repo_evidence | `README.md`, `conductor/product.md`, `src/nlp_policy_nz/cli/main.py` |
| protocol-repo-boundary | repo_evidence | `conductor/tracks/archive/track34_publication_protocol_20260625/spec.md` |
| publication-metadata-standards | blocker | `data/ontologies/data_blocker_register.json`, `data/ontologies/coverage_manifest.json` |
| quality-gates | repo_evidence | `tests/test_track34_publication_protocol.py`, `tests/test_track34_conductor.py` |
| rules-as-code-bridge | repo_evidence | `docs/axiom-foundation-relevance.md`, `src/nlp_policy_nz/axiom/rulespec.py`, `src/nlp_policy_nz/cli/main.py` |
| standards-registry | repo_evidence | `data/ontologies/track26_standards_registry.json`, `data/ontologies/coverage_manifest.json`, `data/ontologies/data_blocker_register.json` |

## Ontology mapping and reasoning

The protocol references Track 29-31 ontology mapping, inference, and NZ ontology candidates as repo evidence. These artifacts are deterministic and review-bounded; authoritative external crosswalks remain explicit gates.

## Corpus statistics and analysis methodology

Track 32 corpus statistics and Track 33 graph/vector analysis are fixture-bounded by default. They can be regenerated locally and extended with supplied full-corpus PipelineRecord, graph, or vector exports.

## Artifact inventory

| Artifact | Type | Present |
| --- | --- | --- |
| `README.md` | overview | True |
| `docs/ontology_mapping.md` | documentation | True |
| `docs/nz_ontologies.md` | documentation | True |
| `docs/corpus_statistics.md` | documentation | True |
| `docs/graph_vector_network_analysis.md` | documentation | True |
| `data/ontologies/coverage_manifest.json` | standards | True |
| `data/ontologies/data_blocker_register.json` | standards | True |
| `data/ontologies/track26_standards_registry.json` | standards | True |
| `data/ontologies/nz_ontology_candidates.json` | ontology | True |
| `data/statistics/corpus_statistics_manifest.json` | analysis | True |
| `data/statistics/corpus_statistics_blockers.json` | analysis | True |
| `data/analysis/graph_vector_manifest.json` | analysis | True |
| `data/analysis/graph_vector_blockers.json` | analysis | True |
| `tests/test_track34_publication_protocol.py` | quality | True |

## Reproducibility instructions

1. `nlp-policy-nz export-nz-ontologies --output-dir data/ontologies`
   - Regenerate deterministic Track 31 ontology artifacts.
2. `nlp-policy-nz corpus-stats --output-dir data/statistics`
   - Regenerate deterministic Track 32 fixture-bounded statistics.
3. `nlp-policy-nz graph-vector-analysis --output-dir data/analysis`
   - Regenerate deterministic Track 33 graph/vector artifacts.
4. `nlp-policy-nz publication-protocol --output-dir data/publication`
   - Regenerate Track 34 publication protocol JSON and Markdown.
5. `pixi run python -m pytest -q tests\test_track34_publication_protocol.py tests\test_track34_conductor.py tests\test_cli.py`
   - Validate Track 34 protocol, conductor, and CLI coverage.

## Overclaim review

| Risk | Level | Safe wording |
| --- | --- | --- |
| full-corpus-overclaim | high | The repository contains deterministic fixture-bounded statistics and can process supplied PipelineRecord Parquet inputs; full-corpus counts remain gated. |
| live-publication-overclaim | high | The repository includes release tooling; live publication requires credentials and an executed external publication run. |
| standards-compliance-overclaim | medium | The protocol lists implemented, partial, planned, and blocked standards coverage with evidence paths. |
| graph-vector-overclaim | medium | Checked-in graph/vector metrics are deterministic and fixture-bounded; full graph/vector publication requires canonical exports. |

## Limitations

- The protocol does not claim full-corpus coverage without supplied full corpus inputs.
- The protocol does not claim live publication without external service execution evidence.
- The protocol does not claim fully implemented DCAT, DCAT-AP, NZGLS, ELI, ELI-DL, ECLI, or LegalRuleML coverage where blocker manifests record partial or missing coverage.
